#!/usr/bin/env bash
# =============================================================================
#  diagnose.sh — Test suite completo v2.1
# =============================================================================
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
BASE="/opt/bwstack"; ENV_FILE="${BASE}/config/.env"
P=0; F=0; W=0

_ok()   { echo -e "  ${G}[PASS]${N} $1"; ((P++)); }
_fail() { echo -e "  ${R}[FAIL]${N} $1  ← $2"; ((F++)); }
_warn() { echo -e "  ${Y}[WARN]${N} $1  ← $2"; ((W++)); }
_t()    { eval "$2" &>/dev/null && _ok "$1" || _fail "$1" "${3:-revisar}"; }
hdr()   { echo -e "\n${B}${C}── $1 ──${N}"; }

echo -e "${B}${C}"
cat << 'BANNER'
  ╔════════════════════════════════════════════╗
  ║   BANDWIDTH STACK — Diagnóstico v2.1       ║
  ╚════════════════════════════════════════════╝
BANNER
echo -e "  $(date '+%Y-%m-%d %H:%M:%S')${N}\n"

source "$ENV_FILE" 2>/dev/null || true

hdr "SISTEMA"
_t "root / sudo disponible"     "[[ \$EUID -eq 0 ]] || sudo -n true" "ejecutar con sudo"
_t "TCP BBR activo"             "sysctl net.ipv4.tcp_congestion_control | grep -q bbr" "modprobe tcp_bbr"
_t "IP forwarding ON"          "[[ \$(cat /proc/sys/net/ipv4/ip_forward) == 1 ]]" "sysctl -w net.ipv4.ip_forward=1"
_t "UFW inactivo"              "! systemctl is-active ufw 2>/dev/null" "ufw disable"
_t "ulimit ≥ 100k"             "[[ \$(ulimit -Hn 2>/dev/null || echo 0) -ge 100000 ]]" "/etc/security/limits.conf"
_t "Node.js ≥ 18"             "node -v 2>/dev/null | grep -qE 'v(1[89]|[2-9][0-9])'" "apt install nodejs"
_t "Python3 disponible"       "command -v python3" "apt install python3"
_t "Docker disponible"        "command -v docker" "apt install docker.io"

hdr "ARCHIVOS"
_t "config/.env existe"        "[[ -f ${ENV_FILE} ]]" "ejecutar install.sh"
_t ".env no vacío"             "[[ -s ${ENV_FILE} ]]" "ejecutar install.sh"
_t "bwctl instalado"           "command -v bwctl" "cp scripts/bwctl.sh /usr/local/bin/bwctl"
_t "web/server.py existe"      "[[ -f ${BASE}/web/server.py ]]" "copiar web/server.py"
_t "Cron healthcheck"          "crontab -l 2>/dev/null | grep -q bwstack" "ejecutar install.sh"
_t "Logrotate bwstack"         "[[ -f /etc/logrotate.d/bwstack ]]" "ejecutar install.sh"
_t "iptables backup existe"    "[[ -f ${BASE}/config/iptables-oracle-backup.rules ]]" "verificar firewall"

hdr "SERVICIOS SYSTEMD"
for svc in mysterium traffmonetizer repocket bitping ui; do
  if systemctl is-enabled "bwstack-${svc}" &>/dev/null 2>&1; then
    systemctl is-active "bwstack-${svc}" &>/dev/null \
      && _ok "bwstack-${svc} activo" \
      || _fail "bwstack-${svc} inactivo" "bwctl restart ${svc}"
  fi
done

hdr "CONTENEDORES DOCKER"
for cname in bws-mysterium bws-packetshare bws-proxyrack; do
  docker inspect "$cname" &>/dev/null 2>&1 || continue
  STATUS=$(docker inspect --format='{{.State.Status}}' "$cname" 2>/dev/null)
  [[ "$STATUS" == "running" ]] && _ok "$cname running" || _fail "$cname ($STATUS)" "docker start $cname"
done

hdr "RED Y PUERTOS"
_t "Internet disponible"       "curl -s --max-time 5 https://1.1.1.1 -o /dev/null" "verificar red"
_t "DNS funciona"              "curl -s --max-time 5 https://api.ipify.org -o /dev/null" "verificar DNS"
[[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] && \
  _t "Puerto 4449 (Mysterium)" "ss -tlnp | grep -q ':4449'" "bwctl restart mysterium"
_t "Puerto 8080 (Dashboard)"   "ss -tlnp | grep -q ':8080'" "bwctl restart ui"

hdr "CONSUMO DE DATOS (10 TB límite/cuenta)"
if command -v vnstat &>/dev/null; then
  NIC=${ORACLE_NIC:-$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5;exit}' || echo eth0)}
  echo -e "  Consumo mensual en $NIC:"
  vnstat -m -i "$NIC" 2>/dev/null | tail -5 | sed 's/^/    /' || echo "  (vnstat sin datos aún)"
else
  _warn "vnstat no instalado" "apt install vnstat"
fi

hdr "MEMORIA POR SERVICIO"
docker stats --no-stream --format "  docker  {{printf \"%-20s\" .Name}} {{.MemUsage}}" 2>/dev/null || true
for svc in mysterium traffmonetizer repocket bitping ui; do
  PID=$(systemctl show -p MainPID --value "bwstack-${svc}" 2>/dev/null || echo "")
  [[ -n "$PID" ]] && [[ "$PID" != "0" ]] && \
    printf "  systemd %-20s %s MB\n" "$svc" \
    "$(cat /proc/${PID}/status 2>/dev/null | awk '/VmRSS/{printf "%.0f",$2/1024}' || echo '—')"
done

hdr "LOGS RECIENTES — ERRORES"
for svc in mysterium traffmonetizer repocket bitping; do
  LOG="${BASE}/logs/${svc}.log"
  [[ -f "$LOG" ]] || continue
  ERRORS=$(grep -iE "error|fatal|failed|panic" "$LOG" 2>/dev/null | tail -2)
  [[ -n "$ERRORS" ]] && echo -e "  ${Y}[$svc]${N}\n$(echo "$ERRORS" | sed 's/^/    /')"
done

echo ""
echo -e "  ══════════════════════════════════════════"
echo -e "  ${G}${P} PASS${N}  ${Y}${W} WARN${N}  ${R}${F} FAIL${N}"
echo ""
[[ $F -eq 0 ]] && [[ $W -le 2 ]] \
  && echo -e "  ${G}${B}✅ Stack en perfecto estado — producción OK${N}" \
  || { [[ $F -eq 0 ]] \
    && echo -e "  ${Y}${B}⚠ Operativo con advertencias menores${N}" \
    || echo -e "  ${R}${B}❌ Hay fallos — revisar arriba${N}"; }
echo ""
