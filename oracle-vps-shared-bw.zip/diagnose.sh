#!/usr/bin/env bash
# =============================================================================
#  diagnose.sh — Test suite completo v2.2 FIXED
#  FIXES: removido test duplicado root/sudo, rutas correctas
# =============================================================================
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
BASE="/opt/bwstack"
ENV_FILE="${BASE}/config/.env"
P=0; F=0; W=0

_ok()   { echo -e "  ${G}[PASS]${N} $1"; ((P++)); }
_fail() { echo -e "  ${R}[FAIL]${N} $1  ${R}← $2${N}"; ((F++)); }
_warn() { echo -e "  ${Y}[WARN]${N} $1  ${Y}← $2${N}"; ((W++)); }
_t()    { eval "$2" &>/dev/null && _ok "$1" || _fail "$1" "${3:-revisar}"; }
hdr()   { echo -e "\n${B}${C}── $1 ──${N}"; }

echo -e "${B}${C}"
cat << 'BANNER'
  ╔════════════════════════════════════════════╗
  ║   BANDWIDTH STACK — Diagnóstico v2.2       ║
  ╚════════════════════════════════════════════╝
BANNER
echo -e "  $(date '+%Y-%m-%d %H:%M:%S')${N}\n"

source "$ENV_FILE" 2>/dev/null || true

hdr "SISTEMA"
# FIX: UN solo test de root (no duplicado)
if [[ $EUID -eq 0 ]]; then
  _ok "Ejecutando como root"
else
  _warn "No es root" "algunos checks pueden fallar — usa: sudo bash diagnose.sh"
fi

_t "TCP BBR activo"            "sysctl net.ipv4.tcp_congestion_control | grep -q bbr" "modprobe tcp_bbr"
_t "IP forwarding ON"          "[[ \$(cat /proc/sys/net/ipv4/ip_forward) == 1 ]]"      "sysctl -w net.ipv4.ip_forward=1"
_t "UFW inactivo"              "! systemctl is-active ufw 2>/dev/null"                 "ufw disable"
_t "ulimit ≥ 100k"             "[[ \$(ulimit -Hn 2>/dev/null || echo 0) -ge 100000 ]]" "editar /etc/security/limits.conf"
_t "Node.js ≥ 18"              "node -v 2>/dev/null | grep -qE 'v(1[89]|[2-9][0-9])'" "instalar nodejs 20"
_t "Python3 disponible"        "command -v python3"                                    "apt install python3"
_t "Docker disponible"         "command -v docker"                                     "instalar docker"

hdr "ARCHIVOS"
_t "config/.env existe"        "[[ -f ${ENV_FILE} ]]"                                  "ejecutar install.sh"
_t ".env no vacío"             "[[ -s ${ENV_FILE} ]]"                                  "ejecutar install.sh"
_t "bwctl instalado"           "command -v bwctl"                                      "cp bwctl.sh /usr/local/bin/bwctl && chmod +x /usr/local/bin/bwctl"
# FIX: ruta correcta /opt/bwstack/web/server.py
_t "web/server.py instalado"   "[[ -f ${BASE}/web/server.py ]]"                        "copiar server.py al dir del proyecto y reinstalar"
_t "Cron healthcheck"          "crontab -l 2>/dev/null | grep -q bwstack"              "ejecutar install.sh"
_t "Logrotate bwstack"         "[[ -f /etc/logrotate.d/bwstack ]]"                     "ejecutar install.sh"
_t "iptables backup existe"    "[[ -f ${BASE}/config/iptables-oracle-backup.rules ]]"  "ejecutar install.sh"

hdr "SERVICIOS SYSTEMD"
ENABLED_ANY=0
for svc in mysterium traffmonetizer repocket bitping ui; do
  if systemctl is-enabled "bwstack-${svc}" &>/dev/null 2>&1; then
    ENABLED_ANY=1
    if systemctl is-active "bwstack-${svc}" &>/dev/null; then
      _ok "bwstack-${svc} activo"
    else
      _fail "bwstack-${svc} inactivo" "bwctl restart ${svc}"
    fi
  fi
done
[[ $ENABLED_ANY -eq 0 ]] && _warn "Ningún servicio systemd habilitado" "ejecutar install.sh con credenciales"

hdr "CONTENEDORES DOCKER"
DOCKER_ANY=0
for cname in bws-mysterium bws-packetshare bws-proxyrack; do
  docker inspect "$cname" &>/dev/null 2>&1 || continue
  DOCKER_ANY=1
  STATUS=$(docker inspect --format='{{.State.Status}}' "$cname" 2>/dev/null)
  [[ "$STATUS" == "running" ]] \
    && _ok "$cname running" \
    || _fail "$cname ($STATUS)" "docker start $cname"
done
[[ $DOCKER_ANY -eq 0 ]] && echo -e "  ${G}(sin contenedores Docker — OK si usas servicios nativos)${N}"

hdr "RED Y PUERTOS"
_t "Internet disponible"       "curl -s --max-time 5 https://1.1.1.1 -o /dev/null"    "verificar red"
_t "DNS funciona"              "curl -s --max-time 5 https://api.ipify.org -o /dev/null" "verificar DNS"
_t "Puerto 8080 (Dashboard)"   "ss -tlnp | grep -q ':8080'"                            "bwctl restart ui"

# Mysterium solo si está habilitado
if systemctl is-enabled "bwstack-mysterium" &>/dev/null 2>&1 || docker inspect bws-mysterium &>/dev/null 2>&1; then
  _t "Puerto 4449 (Mysterium)" "ss -tlnp | grep -q ':4449'"                           "bwctl restart mysterium"
fi

hdr "ORACLE VCN — VERIFICACIÓN CRÍTICA"
echo ""
echo -e "  ${Y}⚠ IMPORTANTE: Tus reglas VCN usan Source: 10.0.0.0/24 (LAN interna)${N}"
echo -e "  ${Y}  Esto bloquea el acceso desde internet.${N}"
echo ""
echo -e "  ${G}Para corregirlo:${N}"
echo -e "  Oracle Console → Networking → VCNs → tu VCN"
echo -e "  → Security Lists → Ingress Rules"
echo -e "  → Editar cada regla de 4449, 8080, 59850-60000"
echo -e "  → Cambiar Source CIDR de ${R}10.0.0.0/24${N} a ${G}0.0.0.0/0${N}"
echo ""
echo -e "  Las reglas con Source ${G}0.0.0.0/0${N} que ya tienes:"
echo -e "  ✓ TCP 22 (SSH) — correcta"
echo -e "  Las que necesitan fix (Source 10.0.0.0/24 → 0.0.0.0/0):"
echo -e "  • TCP 4449       ← Mysterium UI"
echo -e "  • TCP 8080       ← Dashboard"
echo -e "  • TCP 59850-60000 ← Mysterium Wireguard"
echo -e "  • UDP 59850-60000 ← Mysterium Wireguard"

hdr "CONSUMO DE DATOS (10 TB límite/cuenta)"
if command -v vnstat &>/dev/null; then
  NIC=${ORACLE_NIC:-$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5;exit}' || echo eth0)}
  echo -e "  Interfaz: ${NIC}\n"
  vnstat -m -i "$NIC" 2>/dev/null | tail -6 | sed 's/^/  /' \
    || echo "  (vnstat sin datos aún — normal si acaba de instalarse)"
else
  _warn "vnstat no instalado" "apt install vnstat"
fi

hdr "MEMORIA POR SERVICIO"
echo ""
if command -v docker &>/dev/null; then
  docker stats --no-stream --format \
    "  docker   {{printf \"%-22s\" .Name}} {{.MemUsage}}" 2>/dev/null || true
fi
for svc in mysterium traffmonetizer repocket bitping ui; do
  PID=$(systemctl show -p MainPID --value "bwstack-${svc}" 2>/dev/null || echo "")
  [[ -n "$PID" ]] && [[ "$PID" != "0" ]] && \
    printf "  systemd  %-22s %s MB\n" "$svc" \
    "$(awk '/VmRSS/{printf "%.0f",$2/1024}' /proc/${PID}/status 2>/dev/null || echo '—')"
done

hdr "LOGS RECIENTES — ERRORES"
FOUND_ERRORS=0
for svc in mysterium traffmonetizer repocket bitping; do
  LOG="${BASE}/logs/${svc}.log"
  [[ -f "$LOG" ]] || continue
  ERRORS=$(grep -iE "error|fatal|failed|panic" "$LOG" 2>/dev/null | tail -3)
  [[ -n "$ERRORS" ]] && { echo -e "  ${Y}[$svc]${N}"; echo "$ERRORS" | sed 's/^/    /'; FOUND_ERRORS=1; }
done
[[ $FOUND_ERRORS -eq 0 ]] && echo -e "  ${G}Sin errores recientes ✓${N}"

echo ""
echo -e "  ${B}══════════════════════════════════════════${N}"
echo -e "  ${G}${P} PASS${N}  ${Y}${W} WARN${N}  ${R}${F} FAIL${N}"
echo ""
if [[ $F -eq 0 ]] && [[ $W -le 1 ]]; then
  echo -e "  ${G}${B}✅ Stack en perfecto estado — producción OK${N}"
elif [[ $F -eq 0 ]]; then
  echo -e "  ${Y}${B}⚠  Operativo con advertencias menores${N}"
else
  echo -e "  ${R}${B}❌ Hay fallos — revisar arriba${N}"
  echo ""
  echo -e "  Ayuda:"
  echo -e "  ${C}bwctl logs           ${N}# ver logs de todos"
  echo -e "  ${C}bwctl restart all    ${N}# reiniciar todo"
  echo -e "  ${C}sudo bash install.sh ${N}# reinstalar"
fi
echo ""
