#!/usr/bin/env bash
# =============================================================================
#  open_oracle_ports.sh — Abre puertos en Oracle VCN con OCI CLI
# =============================================================================
G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
log()  { echo -e "${G}[✔]${N} $*"; }
warn() { echo -e "${Y}[⚠]${N} $*"; }
step() { echo -e "  ${C}→${N} $*"; }

# Instalar OCI CLI si no existe
if ! command -v oci &>/dev/null; then
  step "Instalando OCI CLI..."
  bash -c "$(curl -fsSL https://raw.githubusercontent.com/oracle/oci-cli/master/scripts/install/install.sh)" \
    -- --accept-all-defaults --install-dir /opt/oci-cli \
    --exec-dir /usr/local/bin --script-dir /opt/oci-cli/bin 2>/dev/null
fi

# Configurar OCI si no existe ~/.oci/config
if [[ ! -f ~/.oci/config ]]; then
  warn "Configura OCI CLI:"
  echo "  1. Oracle Console → User Settings → API Keys → Add API Key → Generate"
  echo "  2. Copia el snippet de configuración"
  echo ""
  oci setup config
fi

echo -e "\n${B}Obteniendo Security Lists disponibles...${N}\n"
# Intentar obtener tenancy automáticamente
TENANCY=$(oci iam tenancy get --query 'data.id' --raw-output 2>/dev/null || echo "")
if [[ -z "$TENANCY" ]]; then
  read -rp "Tenancy OCID: " TENANCY
fi

# Listar Security Lists
oci network security-list list --compartment-id "$TENANCY" --all \
  --query 'data[*].{ID:"id",Nombre:"display-name"}' --output table 2>/dev/null \
  || { warn "No se pudo listar — introduce el OCID manualmente"; }

read -rp "Security List OCID: " SL_ID

# Reglas a añadir
CURRENT=$(oci network security-list get --security-list-id "$SL_ID" \
  --query 'data."ingress-security-rules"' --raw-output 2>/dev/null || echo "[]")

NEW_RULES='[
  {"description":"Mysterium UI","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":4449,"min":4449}}},
  {"description":"Mysterium WG TCP","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":60000,"min":59850}}},
  {"description":"Mysterium WG UDP","is-stateless":false,"protocol":"17","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","udp-options":{"destination-port-range":{"max":60000,"min":59850}}},
  {"description":"BW Dashboard","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":8080,"min":8080}}}
]'

MERGED=$(python3 - << PYEOF
import json
try:
    cur = json.loads('''${CURRENT}''')
except: cur = []
new = json.loads('''${NEW_RULES}''')
descs = {r.get('description','') for r in cur}
merged = cur + [r for r in new if r.get('description','') not in descs]
print(json.dumps(merged))
PYEOF
)

oci network security-list update --security-list-id "$SL_ID" \
  --ingress-security-rules "$MERGED" --force 2>/dev/null

log "Puertos abiertos en Oracle VCN ✓"
log "TCP 4449 | TCP/UDP 59850-60000 | TCP 8080"
warn "Los cambios pueden tardar 30-60s en propagar"
