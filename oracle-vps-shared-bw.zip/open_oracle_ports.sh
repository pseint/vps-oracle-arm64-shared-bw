#!/usr/bin/env bash
# =============================================================================
#  open_oracle_ports.sh v2.3 FIXED
#  FIXES: OCI CLI permission denied, instalación ARM64, fallback a curl
# =============================================================================
set -euo pipefail

G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
log()  { echo -e "${G}[✔]${N} $*"; }
warn() { echo -e "${Y}[⚠]${N} $*"; }
err()  { echo -e "${R}[✘]${N} $*"; }
step() { echo -e "  ${C}→${N} $*"; }
hdr()  { echo -e "\n${B}${C}══ $* ══${N}\n"; }

# ─── Rutas posibles del OCI CLI ───────────────────────────────────────────────
find_oci() {
  for p in \
    /usr/local/bin/oci \
    /opt/oci-cli/bin/oci \
    "${HOME}/bin/oci" \
    "${HOME}/.local/bin/oci" \
    "$(which oci 2>/dev/null || echo '')"; do
    if [[ -f "$p" ]]; then
      chmod +x "$p" 2>/dev/null || true
      echo "$p"; return 0
    fi
  done
  return 1
}

# ─── Instalar OCI CLI correctamente en ARM64 Ubuntu ──────────────────────────
install_oci_cli() {
  hdr "INSTALANDO OCI CLI"

  # Método 1: instalador oficial
  step "Instalando con instalador oficial Oracle..."
  curl -fsSL https://raw.githubusercontent.com/oracle/oci-cli/master/scripts/install/install.sh \
    -o /tmp/oci_install.sh 2>/dev/null

  # Instalar de forma no interactiva
  bash /tmp/oci_install.sh \
    --accept-all-defaults \
    --install-dir /opt/oci-cli \
    --exec-dir /opt/oci-cli/bin \
    --script-dir /opt/oci-cli/scripts \
    2>/dev/null || true

  rm -f /tmp/oci_install.sh

  # Buscar el binario instalado
  OCI_BIN=$(find /opt/oci-cli /root/.local /home -name "oci" -type f 2>/dev/null | head -1 || echo "")

  if [[ -z "$OCI_BIN" ]]; then
    # Método 2: pip3
    step "Intentando con pip3..."
    pip3 install oci-cli --break-system-packages 2>/dev/null \
      || pip3 install oci-cli 2>/dev/null \
      || { err "OCI CLI no pudo instalarse — usando método manual (ver abajo)"; return 1; }
    OCI_BIN=$(which oci 2>/dev/null || echo "")
  fi

  if [[ -n "$OCI_BIN" ]]; then
    chmod +x "$OCI_BIN"
    # Crear symlink accesible
    ln -sf "$OCI_BIN" /usr/local/bin/oci 2>/dev/null || true
    chmod +x /usr/local/bin/oci 2>/dev/null || true
    log "OCI CLI instalado: $OCI_BIN → /usr/local/bin/oci ✓"
    export PATH="/opt/oci-cli/bin:$PATH"
    return 0
  fi

  return 1
}

# ─── Configurar OCI CLI ───────────────────────────────────────────────────────
configure_oci() {
  OCI_CFG="${HOME}/.oci/config"

  if [[ -f "$OCI_CFG" ]] && grep -q "key_file" "$OCI_CFG" 2>/dev/null; then
    log "OCI ya configurado en $OCI_CFG ✓"
    return 0
  fi

  hdr "CONFIGURAR OCI CLI"
  echo -e "  ${Y}Necesitas tus credenciales de Oracle Cloud:${N}"
  echo ""
  echo -e "  ${B}Paso 1:${N} Oracle Console → clic en tu avatar (arriba derecha)"
  echo -e "  ${B}Paso 2:${N} My profile → API keys → Add API key"
  echo -e "  ${B}Paso 3:${N} Generate API key pair → Download private key"
  echo -e "  ${B}Paso 4:${N} Copia el bloque de configuración mostrado"
  echo ""
  echo -e "  ${B}Paso 5:${N} Pega aquí los valores:"
  echo ""

  read -rp "  Tenancy OCID    [ocid1.tenancy.oc1..xxx]: " TENANCY_OCID
  read -rp "  User OCID       [ocid1.user.oc1..xxx]:    " USER_OCID
  read -rp "  Fingerprint     [aa:bb:cc:...]:            " FINGERPRINT
  read -rp "  Region          [sa-santiago-1]:           " REGION
  read -rp "  Ruta de tu key  [/home/dave/.oci/key.pem]:" KEY_FILE

  # Si la key está en el directorio actual, copiarla a ~/.oci/
  if [[ -f "$KEY_FILE" ]]; then
    mkdir -p "${HOME}/.oci"
    cp "$KEY_FILE" "${HOME}/.oci/oci_api_key.pem"
    chmod 600 "${HOME}/.oci/oci_api_key.pem"
    KEY_FILE="${HOME}/.oci/oci_api_key.pem"
    log "Key copiada a ${KEY_FILE} ✓"
  fi

  mkdir -p "${HOME}/.oci"
  cat > "$OCI_CFG" << OCICFG
[DEFAULT]
user=${USER_OCID}
fingerprint=${FINGERPRINT}
tenancy=${TENANCY_OCID}
region=${REGION}
key_file=${KEY_FILE}
OCICFG
  chmod 600 "$OCI_CFG"
  log "OCI configurado en $OCI_CFG ✓"
  export TENANCY_OCID
}

# ─── Abrir puertos con OCI CLI ────────────────────────────────────────────────
open_ports_oci() {
  OCI_BIN="${1:-oci}"
  hdr "ABRIENDO PUERTOS CON OCI CLI"

  # Obtener tenancy
  TENANCY_OCID=$($OCI_BIN iam user list --all 2>/dev/null \
    | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['data'][0]['compartment-id'])" \
    2>/dev/null || echo "")

  if [[ -z "$TENANCY_OCID" ]]; then
    TENANCY_OCID=$(grep "tenancy=" "${HOME}/.oci/config" 2>/dev/null | head -1 | cut -d= -f2 | tr -d ' ')
  fi

  if [[ -z "$TENANCY_OCID" ]]; then
    read -rp "  Tenancy OCID: " TENANCY_OCID
  fi
  log "Tenancy: ${TENANCY_OCID:0:45}..."

  # Listar Security Lists
  echo ""
  step "Security Lists en tu cuenta:"
  $OCI_BIN network security-list list \
    --compartment-id "$TENANCY_OCID" \
    --all \
    --query 'data[*].{ID:"id",Nombre:"display-name"}' \
    --output table 2>/dev/null || {
      warn "No se pudo listar automáticamente"
      echo "  → Ve a Oracle Console → Networking → VCNs → Security Lists"
      echo "  → Copia el OCID de tu Security List"
    }

  echo ""
  read -rp "  OCID de tu Security List: " SL_ID
  [[ -z "$SL_ID" ]] && { err "OCID vacío — abortando"; exit 1; }

  # Obtener reglas actuales
  step "Obteniendo reglas actuales..."
  CURRENT=$($OCI_BIN network security-list get \
    --security-list-id "$SL_ID" \
    --query 'data."ingress-security-rules"' \
    --raw-output 2>/dev/null || echo "[]")

  apply_rules "$OCI_BIN" "$SL_ID" "$CURRENT"
}

# ─── Aplicar las reglas ───────────────────────────────────────────────────────
apply_rules() {
  local OCI_BIN="$1" SL_ID="$2" CURRENT="$3"

  NEW_RULES='[
    {"description":"SSH","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":22,"min":22}}},
    {"description":"Mysterium UI","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":4449,"min":4449}}},
    {"description":"Mysterium WG TCP","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":60000,"min":59850}}},
    {"description":"Mysterium WG UDP","is-stateless":false,"protocol":"17","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","udp-options":{"destination-port-range":{"max":60000,"min":59850}}},
    {"description":"BW Dashboard","is-stateless":false,"protocol":"6","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","tcp-options":{"destination-port-range":{"max":8080,"min":8080}}},
    {"description":"ICMP Frag","is-stateless":false,"protocol":"1","source":"0.0.0.0/0","source-type":"CIDR_BLOCK","icmp-options":{"type":3,"code":4}},
    {"description":"ICMP Unreachable","is-stateless":false,"protocol":"1","source":"10.0.0.0/16","source-type":"CIDR_BLOCK","icmp-options":{"type":3}}
  ]'

  MERGED=$(python3 - << PYEOF
import json
try:
    cur = json.loads('''${CURRENT}''')
except:
    cur = []
new = json.loads(r"""${NEW_RULES}""")
descs = {r.get('description','') for r in cur}
# Eliminar reglas antiguas con source 10.0.0.0/24 para puertos que deben ser públicos
public_ports = {'Mysterium UI','Mysterium WG TCP','Mysterium WG UDP','BW Dashboard'}
cur_clean = [r for r in cur if not (
    r.get('description','') in public_ports and
    r.get('source','') != '0.0.0.0/0'
)]
descs_clean = {r.get('description','') for r in cur_clean}
to_add = [r for r in new if r.get('description','') not in descs_clean]
merged = cur_clean + to_add
print(json.dumps(merged))
PYEOF
)

  step "Aplicando reglas con source 0.0.0.0/0 (internet)..."
  $OCI_BIN network security-list update \
    --security-list-id "$SL_ID" \
    --ingress-security-rules "$MERGED" \
    --force 2>/dev/null

  log "Puertos actualizados con source 0.0.0.0/0 ✓"
  log "TCP 22 (SSH) | TCP 4449 | TCP/UDP 59850-60000 | TCP 8080"
  warn "Los cambios tardan 30-60s en propagar"
}

# ─── MÉTODO MANUAL (fallback si OCI CLI falla) ────────────────────────────────
show_manual_instructions() {
  hdr "INSTRUCCIONES MANUALES — Oracle Console"
  echo ""
  echo -e "  ${Y}OCI CLI no disponible — sigue estos pasos en el navegador:${N}"
  echo ""
  echo -e "  ${B}1.${N} Oracle Console → Networking → Virtual Cloud Networks"
  echo -e "  ${B}2.${N} Clic en tu VCN"
  echo -e "  ${B}3.${N} Security Lists → tu Security List"
  echo -e "  ${B}4.${N} Add Ingress Rules (añadir CADA una):"
  echo ""
  echo -e "  ┌────────────────────────────────────────────────────────────┐"
  echo -e "  │ Source CIDR  Protocol  Port Range  Descripción             │"
  echo -e "  ├────────────────────────────────────────────────────────────┤"
  echo -e "  │ 0.0.0.0/0   TCP       4449        Mysterium UI            │"
  echo -e "  │ 0.0.0.0/0   TCP       59850-60000  Mysterium WG TCP       │"
  echo -e "  │ 0.0.0.0/0   UDP       59850-60000  Mysterium WG UDP       │"
  echo -e "  │ 0.0.0.0/0   TCP       8080        Dashboard               │"
  echo -e "  └────────────────────────────────────────────────────────────┘"
  echo ""
  echo -e "  ${R}⚠ IMPORTANTE:${N} Tus reglas actuales tienen Source ${R}10.0.0.0/24${N}"
  echo -e "  Eso es solo LAN interna. Cambia el Source a ${G}0.0.0.0/0${N}"
  echo ""
  echo -e "  ${B}5.${N} También elimina o edita las reglas existentes con 10.0.0.0/24"
  echo -e "     para los puertos 4449, 8080 y 59850-60000"
  echo ""
}

# ─── MAIN ─────────────────────────────────────────────────────────────────────
main() {
  echo -e "${B}${C}"
  echo "  ╔══════════════════════════════════════════════╗"
  echo "  ║  ORACLE VCN — Apertura de Puertos v2.3       ║"
  echo "  ╚══════════════════════════════════════════════╝"
  echo -e "${N}"

  # 1. Buscar OCI CLI existente
  OCI_BIN=$(find_oci 2>/dev/null || echo "")

  # 2. Si no existe o tiene problemas de permisos, instalar
  if [[ -z "$OCI_BIN" ]]; then
    warn "OCI CLI no encontrado — instalando..."
    install_oci_cli && OCI_BIN=$(find_oci 2>/dev/null || echo "") || true
  else
    # Fix permisos si existe pero falla
    chmod +x "$OCI_BIN" 2>/dev/null || true
    ln -sf "$OCI_BIN" /usr/local/bin/oci 2>/dev/null || true
    chmod +x /usr/local/bin/oci 2>/dev/null || true
    log "OCI CLI encontrado: $OCI_BIN ✓"
  fi

  # 3. Si OCI CLI funciona, usarlo
  if [[ -n "$OCI_BIN" ]] && "$OCI_BIN" --version &>/dev/null 2>&1; then
    export PATH="/opt/oci-cli/bin:${HOME}/bin:${HOME}/.local/bin:$PATH"
    configure_oci
    open_ports_oci "$OCI_BIN"
  else
    # 4. Fallback: instrucciones manuales
    warn "OCI CLI no funcional — mostrando instrucciones manuales"
    show_manual_instructions
  fi
}

main "$@"
