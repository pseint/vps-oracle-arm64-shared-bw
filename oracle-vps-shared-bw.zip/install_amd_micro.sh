#!/usr/bin/env bash
# =============================================================================
#  AMD Micro x86_64 — Instalador Ultraligero v2.1
#  1 GB RAM · ~480 Mbps egreso · 3 proveedores ligeros
# =============================================================================
set -euo pipefail; IFS=$'\n\t'

G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
log()  { echo -e "${G}[✔]${N} $*"; }
warn() { echo -e "${Y}[⚠]${N} $*"; }
hdr()  { echo -e "\n${B}${C}══ $* ══${N}\n"; }
step() { echo -e "  ${C}→${N} $*"; }

BASE="/opt/bwstack"; CFG="${BASE}/config"; BIN="${BASE}/bin"
LOGS="${BASE}/logs"; DATA="${BASE}/data"; WEB="${BASE}/web"
SYSTEMD="/etc/systemd/system"; ENV_FILE="${CFG}/.env"

[[ $EUID -ne 0 ]] && { echo -e "${R}Requiere root${N}"; exit 1; }

hdr "AMD MICRO x86_64 — INSTALADOR ULTRALIGERO v2.1"
RAM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
PUBLIC_IP=$(curl -s --max-time 8 https://api.ipify.org || echo "UNKNOWN")
BW_MBPS=480

log "Arquitectura : $(uname -m)"
log "RAM          : ${RAM_MB} MB"
log "Egreso máx.  : ~${BW_MBPS} Mbps"
log "Ingreso      : Ilimitado"
echo ""
echo -e "  RAM reservada para OS: ~300 MB"
echo -e "  Disponible servicios : ~$((RAM_MB - 300)) MB"
echo -e "  Traffmonetizer: ~50MB | Bitping: ~30MB | Repocket: ~120MB | WebUI: ~25MB"

# ── Sistema ───────────────────────────────────────────────────────────────────
hdr "SISTEMA"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get upgrade -y -qq -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" 2>/dev/null
apt-get install -y -qq curl wget ca-certificates jq cron net-tools ethtool iproute2 python3 vnstat
# Node.js 20 LTS
if ! command -v node &>/dev/null || [[ $(node -v 2>/dev/null | sed 's/v//;s/\..*//' || echo 0) -lt 18 ]]; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - 2>/dev/null
  apt-get install -y -qq nodejs
fi
mkdir -p "$BIN" "$CFG" "$LOGS" "$WEB" "${DATA}/bitping" "${BASE}/services"
chmod 700 "$CFG"
log "Sistema preparado ✓"

# ── Firewall ──────────────────────────────────────────────────────────────────
hdr "FIREWALL"
systemctl is-active ufw &>/dev/null && { ufw --force disable; systemctl disable ufw; }
iptables-save > "${CFG}/iptables-backup.rules" 2>/dev/null || true
_ar() { iptables -C "$@" 2>/dev/null || iptables -A "$@"; }
_ar INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
_ar INPUT -i lo -j ACCEPT
_ar INPUT -p tcp --dport 22   -j ACCEPT
_ar INPUT -p tcp --dport 8080 -j ACCEPT
netfilter-persistent save 2>/dev/null || iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
log "Firewall configurado (reglas Oracle preservadas) ✓"

# ── Kernel micro ──────────────────────────────────────────────────────────────
hdr "TUNING KERNEL AMD MICRO"
grep -q "bwstack-micro" /etc/sysctl.conf 2>/dev/null || cat >> /etc/sysctl.conf << 'SYSCTL'
# bwstack-micro AMD x86_64
net.core.rmem_max                = 67108864
net.core.wmem_max                = 67108864
net.ipv4.tcp_rmem                = 4096 87380 67108864
net.ipv4.tcp_wmem                = 4096 65536 67108864
net.core.default_qdisc           = fq
net.ipv4.tcp_congestion_control  = bbr
net.ipv4.tcp_tw_reuse            = 1
net.ipv4.tcp_fin_timeout         = 20
net.core.somaxconn               = 32768
net.ipv4.ip_local_port_range     = 1024 65535
fs.file-max                      = 500000
# end bwstack-micro
SYSCTL
modprobe tcp_bbr 2>/dev/null || true; sysctl -p /etc/sysctl.conf 2>/dev/null || true
cat >> /etc/security/limits.conf << 'LIM'
* soft nofile 500000
* hard nofile 500000
LIM
NIC=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}' || echo "eth0")
ethtool -K "$NIC" gro on gso on tso on 2>/dev/null || true
log "TCP BBR + buffers 64MB ✓"

# ── Credenciales ──────────────────────────────────────────────────────────────
hdr "CREDENCIALES (3 servicios para 1 GB RAM)"
if [[ -f "$ENV_FILE" ]] && grep -q "TM_TOKEN" "$ENV_FILE" 2>/dev/null; then
  warn "Config existente detectada"
  read -rp "  ¿Reconfigurar? [s/N]: " RC
  [[ "${RC,,}" != "s" ]] && { source "$ENV_FILE"; goto_install=1; }
fi

if [[ "${goto_install:-0}" != "1" ]]; then
  echo -e "${Y}Recomendados para micro 1 GB RAM:${N}\n"
  read -rp "  Traffmonetizer token (vacío=omitir): " TM_TOKEN
  read -rp "  Bitping email (vacío=omitir): " BP_EMAIL
  BP_PASSWORD=""
  [[ -n "${BP_EMAIL:-}" ]] && { read -rsp "  Bitping password: " BP_PASSWORD; echo; }
  read -rp "  Repocket email (vacío=omitir): " RP_EMAIL
  RP_API_KEY=""
  [[ -n "${RP_EMAIL:-}" ]] && read -rp "  Repocket API Key: " RP_API_KEY

  cat >> "$ENV_FILE" << ENV

# AMD Micro — $(date)
PUBLIC_IP=${PUBLIC_IP}
BW_MBPS=${BW_MBPS}
INSTANCE_TYPE=micro
ORACLE_NIC=${NIC}
TM_TOKEN=${TM_TOKEN:-}
BP_EMAIL=${BP_EMAIL:-}
BP_PASSWORD=${BP_PASSWORD:-}
RP_EMAIL=${RP_EMAIL:-}
RP_API_KEY=${RP_API_KEY:-}
ENV
  chmod 600 "$ENV_FILE"
fi
source "$ENV_FILE" 2>/dev/null || true

# ── Traffmonetizer ────────────────────────────────────────────────────────────
if [[ -n "${TM_TOKEN:-}" ]]; then
  hdr "TRAFFMONETIZER"
  TM_BIN="${BIN}/traffmonetizer"
  if [[ ! -f "$TM_BIN" ]]; then
    curl -SL "https://traffmonetizer.com/files/cli_v2/linux/amd64/traffmonetizer" \
      -o "$TM_BIN" 2>/dev/null && chmod +x "$TM_BIN" || {
        warn "Usando Docker mínimo para traffmonetizer"
        cat > "${BASE}/services/tm.yml" << TMDKR
version: "3.8"
services:
  traffmonetizer:
    image: traffmonetizer/cli_v2:latest
    restart: unless-stopped
    command: start accept --token ${TM_TOKEN}
    network_mode: host
    mem_limit: 80m
TMDKR
        command -v docker &>/dev/null || apt-get install -y -qq docker.io
        docker compose -f "${BASE}/services/tm.yml" up -d 2>/dev/null || true
        log "Traffmonetizer Docker mínimo ✓"; goto_tm=1
      }
  fi
  if [[ "${goto_tm:-0}" != "1" ]]; then
    cat > "${SYSTEMD}/bwstack-traffmonetizer.service" << TM
[Unit]
Description=Traffmonetizer (micro)
After=network-online.target
[Service]
ExecStart=${TM_BIN} start accept --token ${TM_TOKEN}
Restart=always; RestartSec=20; MemoryMax=100M; CPUQuota=40%
StandardOutput=append:${LOGS}/traffmonetizer.log
StandardError=append:${LOGS}/traffmonetizer.log
[Install]
WantedBy=multi-user.target
TM
    systemctl daemon-reload; systemctl enable --now bwstack-traffmonetizer.service
    log "Traffmonetizer nativo ✓ (~50 MB)"
  fi
fi

# ── Bitping ───────────────────────────────────────────────────────────────────
if [[ -n "${BP_EMAIL:-}" ]] && [[ -n "${BP_PASSWORD:-}" ]]; then
  hdr "BITPING"
  BP_BIN="${BIN}/bitpingd"
  if [[ ! -f "$BP_BIN" ]]; then
    BP_URL=$(curl -s https://api.github.com/repos/bitping/bitpingd/releases/latest \
      | jq -r '.assets[]|select(.name|test("linux.*(amd64|x86_64)"))|.browser_download_url' \
      2>/dev/null | head -1)
    [[ -n "${BP_URL:-}" ]] && curl -SL "$BP_URL" -o "$BP_BIN" 2>/dev/null && chmod +x "$BP_BIN"
  fi
  [[ -f "$BP_BIN" ]] && {
    cat > "${SYSTEMD}/bwstack-bitping.service" << BP
[Unit]
Description=Bitping (micro)
After=network-online.target
[Service]
Environment=BITPING_EMAIL=${BP_EMAIL}
Environment=BITPING_PASSWORD=${BP_PASSWORD}
ExecStart=${BP_BIN} --data-directory=${DATA}/bitping
Restart=always; RestartSec=20; MemoryMax=60M; CPUQuota=20%
StandardOutput=append:${LOGS}/bitping.log
StandardError=append:${LOGS}/bitping.log
[Install]
WantedBy=multi-user.target
BP
    systemctl daemon-reload; systemctl enable --now bwstack-bitping.service
    log "Bitping nativo ✓ (~30 MB)"
  } || warn "Bitping: binario no descargado"
fi

# ── Repocket ──────────────────────────────────────────────────────────────────
if [[ -n "${RP_EMAIL:-}" ]] && [[ -n "${RP_API_KEY:-}" ]]; then
  hdr "REPOCKET"
  npm install -g @repocket/repocket 2>/dev/null || warn "npm install repocket falló"
  RP_BIN=$(command -v repocket 2>/dev/null || echo "/usr/local/bin/repocket")
  [[ -f "$RP_BIN" ]] && {
    cat > "${SYSTEMD}/bwstack-repocket.service" << RP
[Unit]
Description=Repocket (micro)
After=network-online.target
[Service]
Environment=RP_EMAIL=${RP_EMAIL}
Environment=RP_API_KEY=${RP_API_KEY}
ExecStart=${RP_BIN}
Restart=always; RestartSec=20; MemoryMax=200M; CPUQuota=30%
StandardOutput=append:${LOGS}/repocket.log
StandardError=append:${LOGS}/repocket.log
[Install]
WantedBy=multi-user.target
RP
    systemctl daemon-reload; systemctl enable --now bwstack-repocket.service
    log "Repocket nativo npm ✓ (~120 MB)"
  }
fi

# ── Web UI ────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[[ -f "${SCRIPT_DIR}/../web/server.py" ]] && cp "${SCRIPT_DIR}/../web/server.py" "${WEB}/server.py"
if [[ -f "${WEB}/server.py" ]]; then
  cat > "${SYSTEMD}/bwstack-ui.service" << UI
[Unit]
Description=BW Stack UI (micro)
After=network-online.target
[Service]
ExecStart=/usr/bin/python3 ${WEB}/server.py
WorkingDirectory=${WEB}
Restart=always; RestartSec=10; MemoryMax=60M; CPUQuota=10%
Environment=BW_BASE=${BASE}
Environment=PORT=8080
StandardOutput=append:${LOGS}/webui.log
[Install]
WantedBy=multi-user.target
UI
  systemctl daemon-reload; systemctl enable --now bwstack-ui.service
  log "Web UI → http://${PUBLIC_IP}:8080 ✓"
fi

# ── bwctl ─────────────────────────────────────────────────────────────────────
cp "${SCRIPT_DIR}/bwctl.sh" /usr/local/bin/bwctl 2>/dev/null || true
chmod +x /usr/local/bin/bwctl 2>/dev/null || true

# ── Cron ──────────────────────────────────────────────────────────────────────
CTMP=$(mktemp)
crontab -l 2>/dev/null | grep -v bwstack > "$CTMP" || true
echo "*/5 * * * * /usr/local/bin/bwctl healthcheck >> ${LOGS}/cron.log 2>&1" >> "$CTMP"
crontab "$CTMP"; rm "$CTMP"
systemctl enable --now vnstat 2>/dev/null || true

hdr "✅ AMD MICRO LISTO"
echo -e "  IP: ${B}${PUBLIC_IP}${N} | Egreso: ~${BW_MBPS} Mbps | RAM: ${RAM_MB} MB"
echo -e "  Dashboard: ${C}http://${PUBLIC_IP}:8080${N}"
echo -e "  CLI: ${Y}bwctl status${N}"
echo ""
warn "AMD micro NO soporta Mysterium (requiere >200 MB RAM extra)"
warn "Los 10 TB/mes son por CUENTA Oracle, compartidos con las ARM64"
