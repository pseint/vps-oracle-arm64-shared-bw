#!/usr/bin/env python3
"""
Bandwidth Stack v3 — Web UI
Puerto: 8080 | Auto-refresh: 10s | Sin dependencias externas
"""
import subprocess, json, os, time, re, socket
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime, timedelta
from urllib.parse import urlparse, parse_qs

BASE    = os.environ.get("BW_BASE", "/opt/bwstack")
PORT    = int(os.environ.get("PORT", 8080))
CFG     = f"{BASE}/config/.env"
VERSION = "3.0"

def load_env():
    env = {}
    try:
        with open(CFG) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    env[k.strip()] = v.strip()
    except: pass
    return env

def run(cmd, timeout=5):
    try:
        return subprocess.check_output(cmd, shell=True, text=True,
               stderr=subprocess.DEVNULL, timeout=timeout).strip()
    except: return ""

def get_services():
    names = ["mysterium","traffmonetizer","repocket","bitping","ui"]
    out = []
    for n in names:
        svc = f"bwstack-{n}"
        active = run(f"systemctl is-active {svc}") == "active"
        enabled = run(f"systemctl is-enabled {svc} 2>/dev/null") in ("enabled","static")
        if not enabled: continue
        pid = run(f"systemctl show -p MainPID --value {svc}") if active else "—"
        since_raw = run(f"systemctl show -p ActiveEnterTimestamp --value {svc}")
        out.append({"name": n, "active": active, "pid": pid, "since": since_raw})
    # Docker extras
    for cname in ["bws-packetshare","bws-proxyrack"]:
        r = run(f"docker inspect --format='{{{{.State.Status}}}}' {cname} 2>/dev/null")
        if r: out.append({"name": cname, "active": r=="running", "pid":"docker","since":""})
    return out

def get_sys():
    cpu  = run("top -bn1 | grep 'Cpu' | awk '{printf \"%.1f\", $2+$4}'") or "—"
    mem  = run("free -h | awk 'NR==2{printf \"%s/%s\", $3,$2}'") or "—"
    memf = run("free -m | awk 'NR==2{print $7}'") or "0"
    disk = run("df -h / | awk 'NR==2{printf \"%s/%s (%s)\", $3,$2,$5}'") or "—"
    up   = run("uptime -p") or "—"
    load = run("cat /proc/loadavg | awk '{print $1,$2,$3}'") or "—"
    ip   = run("curl -s --max-time 4 https://api.ipify.org") or socket.gethostbyname(socket.gethostname())
    cpus = run("nproc") or "1"
    bw   = str(int(cpus)*1000) if cpus.isdigit() else "1000"
    nic  = run("ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}'") or "eth0"
    return {"cpu":cpu,"mem":mem,"memfree":memf,"disk":disk,"uptime":up,
            "load":load,"ip":ip,"cpus":cpus,"bw_mbps":bw,"nic":nic}

def get_net(nic):
    try:
        r1=int(open(f"/sys/class/net/{nic}/statistics/rx_bytes").read())
        t1=int(open(f"/sys/class/net/{nic}/statistics/tx_bytes").read())
        time.sleep(0.5)
        r2=int(open(f"/sys/class/net/{nic}/statistics/rx_bytes").read())
        t2=int(open(f"/sys/class/net/{nic}/statistics/tx_bytes").read())
        rx=round((r2-r1)*8/500000,2); tx=round((t2-t1)*8/500000,2)
        return {"rx_mbps":rx,"tx_mbps":tx}
    except: return {"rx_mbps":0,"tx_mbps":0}

def get_logs(svc, lines=50):
    out = run(f"journalctl -u bwstack-{svc} --no-pager -n {lines} 2>/dev/null")
    if not out:
        logf = f"{BASE}/logs/{svc}.log"
        out = run(f"tail -{lines} {logf} 2>/dev/null")
    return out or "(sin logs)"

def render_page(sys_info, services, net, env):
    cpus = sys_info.get("cpus","1")
    bw   = sys_info.get("bw_mbps","1000")
    tx   = net.get("tx_mbps",0)
    rx   = net.get("rx_mbps",0)
    pct  = min(int(float(tx)*100/max(int(bw),1)),100)
    mem_free = int(sys_info.get("memfree","0"))

    def svc_rows():
        rows = ""
        icons = {"mysterium":"🌐","traffmonetizer":"💰","repocket":"🔄",
                 "bitping":"📡","ui":"🖥","bws-packetshare":"📦","bws-proxyrack":"🔗"}
        for s in services:
            ic = icons.get(s["name"],"⚙️")
            dot = "on" if s["active"] else "off"
            status_txt = "activo" if s["active"] else "inactivo"
            rows += f"""
            <tr>
              <td><span class="dot {dot}"></span>{ic} {s['name']}</td>
              <td class="{'ok' if s['active'] else 'err'}">{status_txt}</td>
              <td class="mono">{s['pid']}</td>
              <td>
                <button class="btn btn-sm"
                  onclick="svcAction('{s['name']}','restart')">⟳ restart</button>
                <button class="btn btn-sm btn-stop"
                  onclick="svcAction('{s['name']}','{'stop' if s['active'] else 'start'}')">
                  {'⏹ stop' if s['active'] else '▶ start'}</button>
              </td>
            </tr>"""
        return rows

    env_rows = ""
    SAFE_KEYS = ["PUBLIC_IP","ARCH","CPUS","BW_MBPS","INSTANCE_TYPE","USE_MYSTERIUM",
                 "RP_EMAIL","BP_EMAIL","PS_EMAIL","ORACLE_NIC"]
    for k in SAFE_KEYS:
        v = env.get(k,"")
        if v: env_rows += f"<tr><td class='mono'>{k}</td><td>{v}</td></tr>"

    return f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>BW Stack v{VERSION} — {sys_info.get('ip','')}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap');
  :root{{
    --bg:#080c14;--bg2:#0e1420;--bg3:#141c2a;
    --border:#1e2d45;--accent:#00d4ff;--accent2:#7c3aed;
    --green:#00e676;--red:#ff1744;--yellow:#ffd600;
    --text:#c9d1e0;--dim:#4a5568;
  }}
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{background:var(--bg);color:var(--text);font-family:'Syne',sans-serif;min-height:100vh}}
  .mono{{font-family:'JetBrains Mono',monospace;font-size:.85em}}

  /* Header */
  .header{{
    background:linear-gradient(135deg,#0e1420 0%,#141c2a 100%);
    border-bottom:1px solid var(--border);
    padding:16px 28px;display:flex;align-items:center;justify-content:space-between;
  }}
  .header h1{{font-size:1.3em;font-weight:800;letter-spacing:-0.5px}}
  .header h1 span{{color:var(--accent)}}
  .badge{{background:var(--accent2);color:#fff;font-size:.7em;padding:2px 8px;
          border-radius:99px;margin-left:8px;vertical-align:middle}}
  .header-meta{{font-size:.8em;color:var(--dim);text-align:right}}
  .header-meta strong{{color:var(--accent);display:block;font-size:1.1em}}

  /* Layout */
  .container{{max-width:1200px;margin:0 auto;padding:20px}}
  .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:20px}}

  /* Stat cards */
  .card{{background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:16px;
         position:relative;overflow:hidden;transition:border-color .2s}}
  .card:hover{{border-color:var(--accent)}}
  .card::before{{content:'';position:absolute;top:0;left:0;right:0;height:2px;
                 background:linear-gradient(90deg,var(--accent),var(--accent2))}}
  .card .label{{font-size:.7em;text-transform:uppercase;letter-spacing:1px;color:var(--dim);margin-bottom:6px}}
  .card .value{{font-size:1.25em;font-weight:700;color:#fff}}
  .card .sub{{font-size:.75em;color:var(--dim);margin-top:3px}}

  /* Section */
  .section{{background:var(--bg2);border:1px solid var(--border);border-radius:10px;
            margin-bottom:16px;overflow:hidden}}
  .section-header{{padding:12px 18px;border-bottom:1px solid var(--border);
                   font-weight:700;font-size:.85em;text-transform:uppercase;
                   letter-spacing:.5px;color:var(--accent);display:flex;
                   align-items:center;justify-content:space-between}}
  .section-body{{padding:0}}

  /* Table */
  table{{width:100%;border-collapse:collapse}}
  th{{background:var(--bg3);color:var(--dim);font-size:.7em;text-transform:uppercase;
      letter-spacing:.5px;padding:10px 16px;text-align:left;font-family:'JetBrains Mono',monospace}}
  td{{padding:10px 16px;border-bottom:1px solid var(--border);font-size:.9em}}
  tr:last-child td{{border-bottom:none}}
  tr:hover td{{background:var(--bg3)}}
  .dot{{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:8px}}
  .dot.on{{background:var(--green);box-shadow:0 0 6px var(--green)}}
  .dot.off{{background:var(--red)}}
  .ok{{color:var(--green)}}
  .err{{color:var(--red)}}

  /* Bandwidth bar */
  .bw-bar-wrap{{padding:16px 18px}}
  .bw-label{{display:flex;justify-content:space-between;font-size:.8em;margin-bottom:6px;color:var(--dim)}}
  .bw-bar{{height:10px;background:var(--bg3);border-radius:99px;overflow:hidden;position:relative}}
  .bw-fill{{height:100%;background:linear-gradient(90deg,var(--green),var(--accent));
             border-radius:99px;transition:width .5s ease}}
  .bw-fill.warn{{background:linear-gradient(90deg,var(--yellow),#ff6b00)}}
  .bw-fill.high{{background:linear-gradient(90deg,var(--red),#ff6b00)}}
  .bw-stats{{display:flex;gap:24px;margin-top:10px;font-size:.85em}}
  .bw-stat{{color:var(--dim)}} .bw-stat strong{{color:#fff}}

  /* Buttons */
  .btn{{background:var(--bg3);border:1px solid var(--border);color:var(--text);
        padding:4px 10px;border-radius:6px;cursor:pointer;font-size:.8em;
        font-family:'Syne',sans-serif;transition:all .15s}}
  .btn:hover{{border-color:var(--accent);color:var(--accent)}}
  .btn-stop{{border-color:var(--red);color:var(--red)}}
  .btn-stop:hover{{background:var(--red);color:#fff}}
  .btn-primary{{background:var(--accent2);border-color:var(--accent2);color:#fff;
                padding:8px 18px;font-size:.9em}}
  .btn-primary:hover{{opacity:.85}}

  /* Log viewer */
  .log-viewer{{background:#010408;font-family:'JetBrains Mono',monospace;font-size:.78em;
               color:#8ec07c;padding:14px;height:280px;overflow-y:auto;
               border-top:1px solid var(--border);white-space:pre-wrap;word-break:break-all}}
  .log-tabs{{display:flex;gap:4px;padding:10px 14px;border-bottom:1px solid var(--border)}}
  .log-tab{{padding:4px 12px;border-radius:6px;cursor:pointer;font-size:.8em;
            background:var(--bg3);border:1px solid var(--border);color:var(--dim)}}
  .log-tab.active{{background:var(--accent2);border-color:var(--accent2);color:#fff}}

  /* Toast */
  #toast{{position:fixed;bottom:20px;right:20px;background:var(--accent2);color:#fff;
          padding:10px 20px;border-radius:8px;font-size:.85em;opacity:0;
          transform:translateY(10px);transition:all .3s;pointer-events:none;z-index:999}}
  #toast.show{{opacity:1;transform:translateY(0)}}

  .refresh-badge{{font-size:.7em;color:var(--dim);margin-left:8px}}
  .env-table td:first-child{{color:var(--accent);width:40%}}
</style>
</head>
<body>

<div class="header">
  <div>
    <h1>🌐 <span>Bandwidth</span> Stack <span class="badge">v{VERSION}</span></h1>
    <div style="font-size:.78em;color:var(--dim);margin-top:4px">
      Oracle Free Tier · ARM64 Ampere · Nativo
    </div>
  </div>
  <div class="header-meta">
    <strong>{sys_info.get('ip','')}</strong>
    {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    <span class="refresh-badge">↻ 10s</span>
  </div>
</div>

<div class="container">

  <!-- Stat cards -->
  <div class="grid">
    <div class="card">
      <div class="label">CPU</div>
      <div class="value">{sys_info.get('cpu','—')}%</div>
      <div class="sub">Carga: {sys_info.get('load','—')}</div>
    </div>
    <div class="card">
      <div class="label">Memoria</div>
      <div class="value">{sys_info.get('mem','—')}</div>
      <div class="sub">{mem_free} MB libre</div>
    </div>
    <div class="card">
      <div class="label">Disco</div>
      <div class="value mono" style="font-size:1em">{sys_info.get('disk','—')}</div>
    </div>
    <div class="card">
      <div class="label">BW Egreso máx</div>
      <div class="value">{bw} Mbps</div>
      <div class="sub">{cpus} OCPU × 1 Gbps</div>
    </div>
    <div class="card">
      <div class="label">Uptime</div>
      <div class="value" style="font-size:.95em">{sys_info.get('uptime','—')}</div>
    </div>
    <div class="card">
      <div class="label">Servicios activos</div>
      <div class="value ok">{sum(1 for s in services if s['active'])}/{len(services)}</div>
    </div>
  </div>

  <!-- Bandwidth monitor -->
  <div class="section" style="margin-bottom:16px">
    <div class="section-header">
      📡 Ancho de Banda — {sys_info.get('nic','eth0')}
      <span id="bw-live" style="color:var(--green);font-size:.85em">en vivo</span>
    </div>
    <div class="bw-bar-wrap">
      <div class="bw-label">
        <span>↑ Egreso (TX) — {tx} Mbps</span>
        <span>{pct}% de {bw} Mbps (1 Gbps × {cpus} OCPU)</span>
      </div>
      <div class="bw-bar">
        <div class="bw-fill {'high' if pct>80 else 'warn' if pct>60 else ''}"
             style="width:{pct}%"></div>
      </div>
      <div class="bw-stats">
        <div class="bw-stat">↑ Egreso: <strong>{tx} Mbps</strong></div>
        <div class="bw-stat">↓ Ingreso: <strong>{rx} Mbps</strong> <span style="color:var(--green)">(ilimitado)</span></div>
        <div class="bw-stat">Límite: <strong>{bw} Mbps</strong></div>
      </div>
    </div>
  </div>

  <!-- Services table -->
  <div class="section">
    <div class="section-header">
      ⚙️ Servicios
      <button class="btn btn-primary" onclick="svcAction('all','restart')">⟳ Restart All</button>
    </div>
    <div class="section-body">
      <table>
        <thead><tr>
          <th>Servicio</th><th>Estado</th><th>PID</th><th>Acciones</th>
        </tr></thead>
        <tbody>{svc_rows()}</tbody>
      </table>
    </div>
  </div>

  <!-- Logs -->
  <div class="section">
    <div class="section-header">📋 Logs</div>
    <div class="log-tabs">
      {log_tabs}
    </div>
    <div id="log-content" class="log-viewer">← Selecciona un servicio</div>
  </div>

  <!-- Config -->
  <div class="section">
    <div class="section-header">🔧 Configuración (solo lectura)</div>
    <div class="section-body">
      <table>
        <thead><tr><th>Variable</th><th>Valor</th></tr></thead>
        <tbody class="env-table">{env_rows}</tbody>
      </table>
    </div>
  </div>

</div>

<div id="toast"></div>

<script>
  // Auto refresh page
  setTimeout(()=>location.reload(), 10000);

  function toast(msg, ok=true) {{
    const t=document.getElementById('toast');
    t.textContent=msg;
    t.style.background=ok?'#7c3aed':'#ff1744';
    t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'),3000);
  }}

  function svcAction(svc, action) {{
    fetch(`/api/service?name=${{svc}}&action=${{action}}`)
      .then(r=>r.json())
      .then(d=>toast(d.ok ? `✔ ${{svc}} ${{action}}` : `✘ Error`, d.ok))
      .catch(()=>toast('Error de conexión', false));
  }}

  function loadLog(el, svc) {{
    document.querySelectorAll('.log-tab').forEach(t=>t.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('log-content').textContent = 'Cargando...';
    fetch(`/api/logs?service=${{svc}}`)
      .then(r=>r.json())
      .then(d=>{{
        const el2=document.getElementById('log-content');
        el2.textContent=d.logs||'(sin logs)';
        el2.scrollTop=el2.scrollHeight;
      }});
  }}
</script>
</body>
</html>"""

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def respond(self, code, ctype, body):
        if isinstance(body, str): body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)

        if parsed.path == "/api/logs":
            svc = qs.get("service",["mysterium"])[0]
            logs = get_logs(svc)
            self.respond(200, "application/json", json.dumps({"logs": logs}))

        elif parsed.path == "/api/service":
            svc  = qs.get("name",[""])[0]
            act  = qs.get("action",["restart"])[0]
            if act in ("start","stop","restart") and re.match(r'^[\w-]+$', svc):
                if svc == "all":
                    run(f"bwctl {act} all 2>/dev/null || true", timeout=15)
                else:
                    run(f"systemctl {act} bwstack-{svc} 2>/dev/null || "
                        f"docker {act} bws-{svc} 2>/dev/null || true", timeout=10)
                self.respond(200, "application/json", json.dumps({"ok": True}))
            else:
                self.respond(400, "application/json", json.dumps({"ok": False}))

        elif parsed.path == "/api/status":
            env = load_env()
            sys_info = get_sys()
            net = get_net(sys_info.get("nic","eth0"))
            svcs = get_services()
            self.respond(200, "application/json",
                json.dumps({"sys":sys_info,"net":net,"services":svcs}))

        elif parsed.path in ("/", "/index.html"):
            env = load_env()
            sys_info = get_sys()
            net = get_net(sys_info.get("nic","eth0"))
            svcs = get_services()
            html = render_page(sys_info, svcs, net, env)
            self.respond(200, "text/html; charset=utf-8", html)

        else:
            self.respond(404, "text/plain", "Not found")

if __name__ == "__main__":
    print(f"[BW Stack UI] http://0.0.0.0:{PORT}  — {datetime.now()}")
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
