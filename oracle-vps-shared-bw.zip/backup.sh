#!/usr/bin/env bash
# =============================================================================
#  backup.sh — Backup/Restore cifrado AES-256 de credenciales
# =============================================================================
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; N='\033[0m'
BASE="/opt/bwstack"; BACKUP_DIR="${BASE}/backups"
mkdir -p "$BACKUP_DIR"

backup() {
  echo -e "${C}── Backup de credenciales ──${N}"
  read -rsp "  Passphrase para cifrar (mínimo 12 chars): " PASS; echo
  [[ ${#PASS} -lt 8 ]] && { echo -e "${R}Passphrase muy corta${N}"; exit 1; }

  BFILE="${BACKUP_DIR}/bwstack-$(hostname)-$(date +%Y%m%d-%H%M%S).tar.gz.enc"

  # Crear tar con config + compose
  tar -czf /tmp/bwstack-bk.tar.gz -C "$BASE" \
    config/ 2>/dev/null

  # Cifrar AES-256-CBC
  openssl enc -aes-256-cbc -pbkdf2 -iter 200000 \
    -in /tmp/bwstack-bk.tar.gz \
    -out "$BFILE" \
    -pass "pass:${PASS}"
  rm -f /tmp/bwstack-bk.tar.gz

  echo -e "${G}✔ Backup cifrado: $BFILE${N}"
  echo -e "${Y}⚠ Guarda la passphrase de forma segura — sin ella no puedes restaurar${N}"
  ls -lh "$BFILE"
}

restore() {
  echo -e "${C}── Backups disponibles ──${N}"
  ls -lt "${BACKUP_DIR}"/*.enc 2>/dev/null | head -8 || { echo "Sin backups"; exit 1; }
  echo ""
  read -rp "  Ruta del archivo .enc: " BFILE
  read -rsp "  Passphrase: " PASS; echo

  openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
    -in "$BFILE" -out /tmp/bwstack-restore.tar.gz \
    -pass "pass:${PASS}" \
    || { echo -e "${R}✘ Passphrase incorrecta o archivo corrupto${N}"; exit 1; }

  tar -xzf /tmp/bwstack-restore.tar.gz -C "$BASE"
  rm -f /tmp/bwstack-restore.tar.gz
  echo -e "${G}✔ Backup restaurado en $BASE/config/${N}"
}

auto_backup() {
  # Para cron semanal — usa passphrase de variable de entorno
  [[ -z "${BACKUP_PASS:-}" ]] && { echo "Set BACKUP_PASS env var"; exit 1; }
  BFILE="${BACKUP_DIR}/auto-$(date +%Y%m%d).tar.gz.enc"
  tar -czf /tmp/bwstack-bk.tar.gz -C "$BASE" config/ 2>/dev/null
  openssl enc -aes-256-cbc -pbkdf2 -iter 200000 \
    -in /tmp/bwstack-bk.tar.gz -out "$BFILE" -pass "pass:${BACKUP_PASS}"
  rm -f /tmp/bwstack-bk.tar.gz
  # Mantener solo los 4 backups más recientes
  ls -t "${BACKUP_DIR}"/auto-*.enc 2>/dev/null | tail -n +5 | xargs rm -f 2>/dev/null || true
  echo "$(date) — Backup auto: $BFILE"
}

case "${1:-backup}" in
  backup)  backup ;;
  restore) restore ;;
  auto)    auto_backup ;;
  *) echo "Uso: $0 [backup|restore|auto]" ;;
esac
