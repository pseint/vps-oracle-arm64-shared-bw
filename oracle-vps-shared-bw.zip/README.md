# 🌐 Bandwidth Stack v2.1 FINAL
## Oracle Free Tier · ARM64 Ampere + AMD Micro · Producción Real

---

## 📦 Estructura del Proyecto

```
bwstack-final/
├── install.sh                  ← ENTRADA PRINCIPAL (auto-detecta instancia)
├── scripts/
│   ├── install_arm64.sh        ← ARM64 Ampere A1: 6 proveedores, nativo
│   ├── install_amd_micro.sh    ← AMD Micro x86_64: 3 proveedores ligeros
│   ├── bwctl.sh                ← CLI de gestión completo
│   ├── deploy_multi.sh         ← Deploy masivo en todas las instancias
│   ├── diagnose.sh             ← Test suite: 20+ verificaciones
│   ├── setup_telegram.sh       ← Alertas Telegram automáticas
│   ├── open_oracle_ports.sh    ← Abre puertos VCN con OCI CLI
│   └── backup.sh               ← Backup/restore cifrado AES-256
└── web/
    └── server.py               ← Dashboard web Python (puerto 8080)
```

---

## ⚡ Arquitectura: Nativo vs Docker

```
Versiones anteriores          v2.1 FINAL
────────────────────          ──────────────────────────────
Docker × 6 = ~800 MB RAM      Nativo systemd = ~275 MB RAM
Docker daemon overhead        Sin overhead de orquestación
Variables mal pasadas         env vars directas al proceso
UFW conflictos                UFW desactivado + Oracle safe
Bitping interactivo           Bitping por env vars ✓
iptables -F borraba Oracle    -C check antes de -A ✓
```

---

## 📊 Límites Reales Oracle Free Tier (2025)

```
ANCHO DE BANDA:
  Egreso  → 1 Gbps × número de OCPUs de la instancia
  Ingreso → ILIMITADO y GRATIS

DATOS MENSUALES:
  10 TB/mes SALIENTE → por CUENTA (no por instancia)
  Si tienes 4 instancias en 1 cuenta → comparten los 10 TB
  Cada cuenta en región diferente → 10 TB INDEPENDIENTES

INSTANCIAS GRATUITAS POR CUENTA:
  ARM64 Ampere A1: pool de 4 OCPU + 24 GB RAM
    → 4 instancias de 1 OCPU + 6 GB cada una ← ÓPTIMO
    → O 1 instancia de 4 OCPU + 24 GB
  AMD E2 Micro: 2 instancias × 1 GB RAM × ~480 Mbps
```

---

## 🗺️ Configuración Óptima (máximos ingresos)

```
MISMA CUENTA — 6 instancias — 6 IPs:

  ARM64 #1 (IP_1) — 1 OCPU — 1 Gbps — 6 GB RAM
  ARM64 #2 (IP_2) — 1 OCPU — 1 Gbps — 6 GB RAM
  ARM64 #3 (IP_3) — 1 OCPU — 1 Gbps — 6 GB RAM
  ARM64 #4 (IP_4) — 1 OCPU — 1 Gbps — 6 GB RAM
  AMD Micro #1 (IP_5) — ~480 Mbps — 1 GB RAM
  AMD Micro #2 (IP_6) — ~480 Mbps — 1 GB RAM
  ─────────────────────────────────────────────
  Total IPs activas   : 6
  Total egreso máx    : ~4.96 Gbps
  Datos gratis/mes    : 10 TB (compartidos en cuenta)
  Costo servidor      : $0 ← Oracle Always Free
```

---

## 🚀 Instalación — Orden Exacto

### 1. En cada instancia ARM64 (repetir ×4)
```bash
# Copiar proyecto a la instancia
scp -r -i ~/.ssh/oracle.pem bwstack-final/ ubuntu@IP:/tmp/

# Instalar
ssh -i ~/.ssh/oracle.pem ubuntu@IP
sudo bash /tmp/bwstack-final/install.sh
```

### 2. En cada AMD Micro (repetir ×2)
```bash
scp -r -i ~/.ssh/oracle.pem bwstack-final/ ubuntu@IP_MICRO:/tmp/
ssh -i ~/.ssh/oracle.pem ubuntu@IP_MICRO
sudo bash /tmp/bwstack-final/scripts/install_amd_micro.sh
```

### 3. Deploy masivo desde tu PC local (alternativa)
```bash
# Editar IPs en deploy_multi.sh, luego:
bash scripts/deploy_multi.sh
# Opción 1: deploy en todas a la vez
```

### 4. Abrir puertos Oracle VCN (una vez por cuenta)
```bash
sudo bash scripts/open_oracle_ports.sh
# O manual: Oracle Console → VCN → Security Lists → Ingress:
# TCP 4449 | TCP/UDP 59850-60000 | TCP 8080
```

### 5. Alertas Telegram (recomendado)
```bash
sudo bash scripts/setup_telegram.sh setup
```

### 6. Verificación final
```bash
sudo bash scripts/diagnose.sh
# Debe dar 0 FAIL
```

---

## 💻 CLI bwctl — Referencia Completa

```bash
bwctl status              # Estado de todos los servicios + recursos
bwctl logs                # Logs de todos (Ctrl+C para salir)
bwctl logs mysterium      # Logs de un servicio específico
bwctl restart all         # Reiniciar todo el stack
bwctl restart mysterium   # Reiniciar solo Mysterium
bwctl stop all            # Detener todo
bwctl start all           # Iniciar todo
bwctl bandwidth           # Monitor de ancho de banda en tiempo real ← muy útil
bwctl info                # Info del sistema + límites Oracle
bwctl healthcheck         # Verificar y reiniciar caídos
bwctl update              # Actualizar binarios y packages
```

---

## 🌐 Dashboard Web — http://IP:8080

**Funciones:**
- Estado de todos los servicios (verde/rojo) con botones restart/stop
- Gráfica de ancho de banda TX/RX en tiempo real
- Uso de CPU, RAM, disco
- Visor de logs por servicio (click en pestaña)
- Variables de configuración (sin contraseñas)
- Auto-refresh cada 10 segundos

---

## 📋 Post-instalación — Checklist

### Cada instancia ARM64:
- [ ] `bwctl status` → todos los servicios en verde
- [ ] `bash scripts/diagnose.sh` → 0 FAIL
- [ ] Dashboard en `http://IP:8080` accesible
- [ ] Mysterium UI en `http://IP:4449` → **conectar wallet** (necesitas MATIC para gas)
- [ ] Mysterium → activar servicios: Wireguard + Datacenter Proxy
- [ ] Telegram: recibir mensaje de prueba

### Cada AMD Micro:
- [ ] `bwctl status` → servicios ligeros en verde
- [ ] Dashboard en `http://IP:8080` accesible

### Una sola vez por cuenta:
- [ ] Oracle VCN Security List → puertos abiertos
- [ ] Registrar cuentas en los 6 proveedores antes de instalar
- [ ] `bash scripts/backup.sh` → guardar backup cifrado de credenciales

---

## 💰 Proyección de Ganancias Actualizada v2.1

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESCENARIO CONSERVADOR — 6 IPs activas
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4× ARM64 (datacenter IP, tráfico moderado):
  Mysterium      × 4 = $20/mes  ($5 por nodo)
  Traffmonetizer × 4 =  $8/mes  ($2 por nodo)
  Repocket       × 4 =  $8/mes  ($2 por nodo)
  Bitping        × 4 =  $2/mes  ($0.50 por nodo)
  PacketShare    × 4 =  $6/mes  ($1.50 por nodo)
  ProxyRack      × 4 =  $8/mes  ($2 por nodo)
  ─────────────────────────────────────
  Subtotal ARM64 : $52/mes

2× AMD Micro (IP datacenter, ligeros):
  Traffmonetizer × 2 = $2/mes
  Bitping        × 2 = $1/mes
  Repocket       × 2 = $2/mes
  ─────────────────────────────────────
  Subtotal Micro : $5/mes

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL CONSERVADOR:  ~$57/mes  ← mismo que v2 + micro
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ESCENARIO OPTIMISTA — alta demanda / Mysterium activo
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4× ARM64:
  Mysterium      × 4 = $120/mes ($30 por nodo)
  Traffmonetizer × 4 =  $12/mes
  Repocket       × 4 =  $12/mes
  Bitping        × 4 =   $4/mes
  PacketShare    × 4 =   $8/mes
  ProxyRack      × 4 =  $20/mes
  ─────────────────────────────────────
  Subtotal ARM64 : $176/mes

2× AMD Micro:
  Subtotal Micro :  $10/mes

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL OPTIMISTA:   ~$186/mes
Costo servidor:      $0  ← Oracle Always Free
GANANCIA NETA:     $57 – $186/mes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CUENTAS ADICIONALES (Europa/Asia/USA/Canadá):
  Cada cuenta adicional agrega otros $57–$186/mes
  con 10 TB propios independientes
```

---

## 🔌 Proveedores — Registro y Configuración

| # | Proveedor | Web | Acepta VPS | Pago | Configuración |
|---|-----------|-----|-----------|------|---------------|
| 1 | **Mysterium** | mystnodes.com | ✅ | MYST crypto | Web UI :4449 tras instalar |
| 2 | **Traffmonetizer** | traffmonetizer.com | ✅ | BTC | Token en dashboard → .env |
| 3 | **Repocket** | repocket.co | ✅ | PayPal/Wise | Email + API Key → .env |
| 4 | **Bitping** | bitping.com | ✅ | SOL (Solana) | Email + Password → .env |
| 5 | **PacketShare** | packetshare.io | ✅ | PayPal | Email + Password → .env |
| 6 | **ProxyRack** | peer.proxyrack.com | ✅ | PayPal | API Key → .env |

> **IPs Oracle (AS31898)** se clasifican como datacenter/hosting.
> Los 6 proveedores del stack las aceptan explícitamente.
> Honeygain, EarnApp e IPRoyal Pawns **NO** aceptan IPs datacenter.

---

## 🔧 Troubleshooting

```bash
# Servicio no arranca
bwctl logs mysterium
journalctl -u bwstack-mysterium -n 50

# Verificar cuántos TB has gastado este mes
vnstat -m -i eth0

# RAM usada por cada servicio
bwctl status  # muestra memoria en la sección recursos

# Reinstalar un servicio específico
systemctl stop bwstack-mysterium
rm /etc/systemd/system/bwstack-mysterium.service
sudo bash scripts/install_arm64.sh  # solo reinstala lo que falta

# Restaurar credenciales desde backup
bash scripts/backup.sh restore
```
