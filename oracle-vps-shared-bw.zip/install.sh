#!/usr/bin/env bash
# =============================================================================
#  BANDWIDTH STACK — MASTER INSTALLER v2.2 FIXED
#  Estructura PLANA: todos los archivos en el mismo directorio
# =============================================================================
set -euo pipefail; IFS=$'\n\t'

STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'

[[ $EUID -ne 0 ]] && { echo -e "${R}Requiere root: sudo bash install.sh${N}"; exit 1; }

echo -e "${B}${C}"
cat << 'BANNER'
  ╔══════════════════════════════════════════════════════════════╗
  ║   BANDWIDTH STACK v2.2 — Oracle Free Tier ARM64             ║
  ║   Mysterium · Traffmonetizer · Repocket · Bitping           ║
  ╚══════════════════════════════════════════════════════════════╝
BANNER
echo -e "${N}"

ARCH=$(uname -m)
RAM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
echo -e "  Arquitectura : ${C}${ARCH}${N}  |  RAM: ${C}${RAM_MB} MB${N}\n"

# Verificar archivos en el mismo directorio (estructura plana)
MISSING=0
for f in install_arm64.sh install_amd_micro.sh bwctl.sh server.py; do
  [[ ! -f "${STACK_DIR}/${f}" ]] && {
    echo -e "  ${R}✘ Falta: ${f}${N}"; MISSING=1; }
done
[[ $MISSING -eq 1 ]] && {
  echo -e "\n${Y}Ejecuta desde el directorio del proyecto:${N}"
  echo -e "  cd ~/vps-oracle-arm64-shared-bw && sudo bash install.sh"; exit 1; }

if [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
  echo -e "  ${G}→ ARM64 Ampere A1 — instalador completo (6 proveedores)${N}\n"
  bash "${STACK_DIR}/install_arm64.sh"
elif [[ "$ARCH" == "x86_64" ]] && [[ "$RAM_MB" -le 1200 ]]; then
  echo -e "  ${Y}→ AMD Micro — instalador ultraligero (3 proveedores)${N}\n"
  bash "${STACK_DIR}/install_amd_micro.sh"
else
  echo -e "  ${C}→ x86_64 — instalador completo${N}\n"
  bash "${STACK_DIR}/install_arm64.sh"
fi
