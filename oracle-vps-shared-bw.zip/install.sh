#!/usr/bin/env bash
# =============================================================================
#  BANDWIDTH STACK — MASTER INSTALLER v2.1 FINAL
#  Auto-detecta: ARM64 Ampere A1 | AMD x86_64 Micro
#  Oracle Free Tier · Ubuntu 22.04 · Producción Real
# =============================================================================
set -euo pipefail; IFS=$'\n\t'

STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colores
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
C='\033[0;36m'; B='\033[1m'; N='\033[0m'

banner() {
cat << 'BANNER'
 ██████╗ ██╗    ██╗    ███████╗████████╗ █████╗  ██████╗██╗  ██╗
 ██╔══██╗██║    ██║    ██╔════╝╚══██╔══╝██╔══██╗██╔════╝██║ ██╔╝
 ██████╔╝██║ █╗ ██║    ███████╗   ██║   ███████║██║     █████╔╝ 
 ██╔══██╗██║███╗██║    ╚════██║   ██║   ██╔══██║██║     ██╔═██╗ 
 ██████╔╝╚███╔███╔╝    ███████║   ██║   ██║  ██║╚██████╗██║  ██╗
 ╚═════╝  ╚══╝╚══╝     ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝
     ORACLE FREE TIER — BANDWIDTH MONETIZATION v2.1 FINAL
BANNER
echo ""
}

[[ $EUID -ne 0 ]] && { echo -e "${R}Requiere root: sudo bash install.sh${N}"; exit 1; }

banner

ARCH=$(uname -m)
RAM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)

echo -e "${B}Detectando tipo de instancia...${N}"
echo -e "  Arquitectura : ${C}${ARCH}${N}"
echo -e "  RAM          : ${C}${RAM_MB} MB${N}"
echo ""

if [[ "$ARCH" == "aarch64" ]] || [[ "$ARCH" == "arm64" ]]; then
    echo -e "  ${G}→ Instancia ARM64 Ampere A1 detectada${N}"
    echo -e "  ${G}→ Ejecutando instalador completo (6 proveedores)${N}\n"
    bash "${STACK_DIR}/scripts/install_arm64.sh"
elif [[ "$ARCH" == "x86_64" ]] && [[ "$RAM_MB" -le 1200 ]]; then
    echo -e "  ${Y}→ Instancia AMD Micro detectada (${RAM_MB} MB RAM)${N}"
    echo -e "  ${Y}→ Ejecutando instalador ultraligero (3 proveedores)${N}\n"
    bash "${STACK_DIR}/scripts/install_amd_micro.sh"
elif [[ "$ARCH" == "x86_64" ]]; then
    echo -e "  ${C}→ x86_64 con RAM suficiente → usando instalador completo${N}\n"
    bash "${STACK_DIR}/scripts/install_arm64.sh"
else
    echo -e "${R}Arquitectura no soportada: ${ARCH}${N}"; exit 1
fi
