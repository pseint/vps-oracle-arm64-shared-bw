#!/usr/bin/env bash
# =============================================================================
#  deploy_multi.sh — Deploy en múltiples instancias Oracle vía SSH
# =============================================================================
set -euo pipefail
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
log()  { echo -e "${G}[✔]${N} $*"; }
warn() { echo -e "${Y}[⚠]${N} $*"; }
hdr()  { echo -e "\n${B}${C}══ $* ══${N}\n"; }

# ── EDITA ESTAS IPs ───────────────────────────────────────────────────────────
ARM64_INSTANCES=(
  "IP_ARM64_1"
  "IP_ARM64_2"
  "IP_ARM64_3"
  "IP_ARM64_4"
)
MICRO_INSTANCES=(
  "IP_MICRO_1"
  "IP_MICRO_2"
)
SSH_USER="ubuntu"
SSH_KEY="${HOME}/.ssh/oracle_key.pem"
STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ssh_cmd() { ssh -i "$SSH_KEY" -o ConnectTimeout=10 -o StrictHostKeyChecking=no "$SSH_USER@$1" "${@:2}"; }
scp_dir() { scp -r -i "$SSH_KEY" -o StrictHostKeyChecking=no "$1" "$SSH_USER@$2:/tmp/bwstack/"; }

deploy_one() {
  local ip="$1"; local type="$2"
  echo -e "\n${C}── Desplegando en $ip ($type) ──${N}"
  ssh_cmd "$ip" "echo ok" &>/dev/null || { warn "Sin conexión a $ip — saltando"; return 1; }
  ssh_cmd "$ip" "mkdir -p /tmp/bwstack"
  scp_dir "${STACK_DIR}/." "$ip" 2>/dev/null || true
  if [[ "$type" == "arm64" ]]; then
    ssh_cmd "$ip" "chmod +x /tmp/bwstack/install.sh /tmp/bwstack/scripts/*.sh && sudo bash /tmp/bwstack/install.sh" \
      2>&1 | tee "/tmp/deploy_${ip}.log"
  else
    ssh_cmd "$ip" "chmod +x /tmp/bwstack/scripts/install_amd_micro.sh && sudo bash /tmp/bwstack/scripts/install_amd_micro.sh" \
      2>&1 | tee "/tmp/deploy_${ip}.log"
  fi
  log "Deploy en $ip completado → log: /tmp/deploy_${ip}.log"
}

status_all() {
  hdr "ESTADO DE TODAS LAS INSTANCIAS"
  for ip in "${ARM64_INSTANCES[@]}" "${MICRO_INSTANCES[@]}"; do
    echo -e "\n${C}── $ip ──${N}"
    ssh_cmd "$ip" "bwctl status 2>/dev/null || echo 'bwctl no instalado'" 2>/dev/null \
      || echo "Sin conexión"
  done
}

main() {
  [[ ! -f "$SSH_KEY" ]] && { warn "Llave SSH no en $SSH_KEY"; read -rp "Ruta SSH key: " SSH_KEY; }
  echo -e "${B}${C}  BANDWIDTH STACK — DEPLOY MULTI-INSTANCIA${N}\n"
  echo "  1) Deploy en TODAS las instancias (ARM64 + micro)"
  echo "  2) Deploy solo ARM64 (×${#ARM64_INSTANCES[@]})"
  echo "  3) Deploy solo AMD micro (×${#MICRO_INSTANCES[@]})"
  echo "  4) Ver estado de todas"
  echo "  5) Deploy en IP específica"
  echo ""
  read -rp "  Opción [1-5]: " OPT

  case $OPT in
    1)
      warn "Deploy en ${#ARM64_INSTANCES[@]} ARM64 + ${#MICRO_INSTANCES[@]} micro"
      read -rp "  Confirmar [s/N]: " C2; [[ "${C2,,}" != "s" ]] && exit 0
      for ip in "${ARM64_INSTANCES[@]}"; do deploy_one "$ip" "arm64" || true; done
      for ip in "${MICRO_INSTANCES[@]}"; do deploy_one "$ip" "micro" || true; done
      log "Deploy masivo completado" ;;
    2) for ip in "${ARM64_INSTANCES[@]}"; do deploy_one "$ip" "arm64" || true; done ;;
    3) for ip in "${MICRO_INSTANCES[@]}"; do deploy_one "$ip" "micro" || true; done ;;
    4) status_all ;;
    5)
      read -rp "  IP destino: " TARGET
      read -rp "  Tipo [arm64/micro]: " TYPE
      deploy_one "$TARGET" "${TYPE:-arm64}" ;;
    *) warn "Opción inválida" ;;
  esac
}

main "$@"
