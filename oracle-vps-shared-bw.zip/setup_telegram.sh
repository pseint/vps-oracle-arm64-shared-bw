#!/usr/bin/env bash
# =============================================================================
#  setup_telegram.sh — Alertas Telegram v2.1
#  Notifica: caída de servicio, reinicio, reporte diario, uso disco
# =============================================================================
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; C='\033[0;36m'; N='\033[0m'
BASE="/opt/bwstack"; TG_CFG="${BASE}/config/telegram.conf"
STATE_DIR="${BASE}/config/state"; LOG="${BASE}/logs/alerts.log"

send_tg() {
  [[ ! -f "$TG_CFG" ]] && return
  source "$TG_CFG"
  curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendMessage" \
    -d chat_id="${TG_CHAT_ID}" \
    -d text="$1" -d parse_mode="Markdown" > /dev/null 2>&1
}

setup() {
  echo -e "\n${C}── Configurar Bot Telegram ──${N}"
  echo "  1. Busca @BotFather en Telegram"
  echo "  2. Envía /newbot → obtén TOKEN"
  echo "  3. Busca @userinfobot → /start → obtén Chat ID"
  echo ""
  read -rp "  TOKEN del bot: " TG_TOKEN
  read -rp "  Tu Chat ID:    " TG_CHAT_ID

  RESP=$(curl -s "https://api.telegram.org/bot${TG_TOKEN}/getMe" | grep -o '"ok":true' || echo "")
  [[ "$RESP" != '"ok":true' ]] && { echo -e "${R}Token inválido${N}"; exit 1; }

  mkdir -p "${BASE}/config"; chmod 700 "${BASE}/config"
  printf "TG_TOKEN=%s\nTG_CHAT_ID=%s\n" "$TG_TOKEN" "$TG_CHAT_ID" > "$TG_CFG"
  chmod 600 "$TG_CFG"
  echo -e "${G}✓ Configurado${N}"

  # Instalar script de monitoreo
  mkdir -p "$STATE_DIR"
  install_monitor

  # Cron cada 5 min
  CTMP=$(mktemp)
  crontab -l 2>/dev/null | grep -v tg_monitor > "$CTMP" || true
  echo "*/5 * * * * ${BASE}/scripts/tg_monitor.sh >> ${LOG} 2>&1" >> "$CTMP"
  crontab "$CTMP"; rm "$CTMP"

  # Mensaje de prueba
  PUBLIC_IP=$(curl -s --max-time 5 https://api.ipify.org 2>/dev/null || echo "?")
  send_tg "🟢 *Bandwidth Stack v2.1*
Alertas configuradas en \`$(hostname)\`
🌐 IP: \`${PUBLIC_IP}\`
✅ Sistema activo y monitoreado
_$(date '+%Y-%m-%d %H:%M')_"
  echo -e "${G}✓ Mensaje de prueba enviado a Telegram${N}"
}

install_monitor() {
  cat > "${BASE}/scripts/tg_monitor.sh" << 'MON'
#!/usr/bin/env bash
BASE="/opt/bwstack"
TG_CFG="${BASE}/config/telegram.conf"
STATE_DIR="${BASE}/config/state"
[[ ! -f "$TG_CFG" ]] && exit 0
source "$TG_CFG"

_send() {
  curl -s -X POST "https://api.telegram.org/bot${TG_TOKEN}/sendMessage" \
    -d chat_id="${TG_CHAT_ID}" -d text="$1" -d parse_mode="Markdown" > /dev/null 2>&1
  echo "[$(date '+%H:%M')] $1" >> "${BASE}/logs/alerts.log"
}

# Verificar servicios
for svc in mysterium traffmonetizer repocket bitping ui; do
  systemctl is-enabled "bwstack-${svc}" &>/dev/null 2>&1 || continue
  SF="${STATE_DIR}/${svc}.state"
  PREV=$(cat "$SF" 2>/dev/null || echo "running")
  CUR=$(systemctl is-active "bwstack-${svc}" 2>/dev/null || echo "inactive")
  if [[ "$CUR" != "running" ]] && [[ "$CUR" != "active" ]] && [[ "$PREV" == "running" ]]; then
    _send "🔴 *bwstack-${svc}* caído en \`$(hostname)\`
Reiniciando automáticamente..."
    systemctl restart "bwstack-${svc}" 2>/dev/null && sleep 5
    NEW=$(systemctl is-active "bwstack-${svc}" 2>/dev/null || echo "failed")
    [[ "$NEW" == "active" ]] \
      && _send "✅ *bwstack-${svc}* recuperado en \`$(hostname)\`" \
      || _send "❌ *bwstack-${svc}* NO pudo reiniciarse — requiere intervención"
  fi
  echo "$CUR" > "$SF"
done

# Docker
for cn in bws-packetshare bws-proxyrack bws-mysterium; do
  docker inspect "$cn" &>/dev/null 2>&1 || continue
  SF="${STATE_DIR}/${cn}.state"; PREV=$(cat "$SF" 2>/dev/null || echo "running")
  CUR=$(docker inspect --format='{{.State.Status}}' "$cn" 2>/dev/null || echo "gone")
  [[ "$CUR" != "running" ]] && [[ "$PREV" == "running" ]] && {
    _send "🔴 Docker *${cn}* caído — reiniciando..."
    docker start "$cn" 2>/dev/null && _send "✅ Docker *${cn}* recuperado" \
      || _send "❌ Docker *${cn}* no pudo reiniciarse"
  }
  echo "$CUR" > "$SF"
done

# Disco >85%
DISK=$(df / | awk 'NR==2{print $5}' | tr -d '%')
SF="${STATE_DIR}/disk.state"; PREV=$(cat "$SF" 2>/dev/null || echo "0")
[[ "$DISK" -ge 85 ]] && [[ "$PREV" -lt 85 ]] && {
  _send "⚠️ Disco al *${DISK}%* en \`$(hostname)\`
Limpiando imágenes Docker..."
  docker image prune -f >> "${BASE}/logs/alerts.log" 2>&1
  NEW=$(df / | awk 'NR==2{print $5}' | tr -d '%')
  _send "🧹 Disco: *${DISK}%* → *${NEW}%* tras limpieza"
}
echo "$DISK" > "$SF"

# Reporte diario 08:00
HOUR=$(date +%H); TODAY=$(date +%Y-%m-%d)
SF="${STATE_DIR}/daily.state"; LAST=$(cat "$SF" 2>/dev/null || echo "")
[[ "$HOUR" == "08" ]] && [[ "$LAST" != "$TODAY" ]] && {
  RUNNING=$(systemctl list-units 'bwstack-*' --state=active --no-legend \
    | awk '{print $1}' | sed 's/bwstack-//;s/\.service//' | tr '\n' ', ' | sed 's/,$//')
  DISK_I=$(df -h / | awk 'NR==2{printf "%s/%s", $3,$2}')
  IP=$(curl -s --max-time 4 https://api.ipify.org 2>/dev/null || echo "?")
  NIC=${ORACLE_NIC:-eth0}
  BW_OUT=$(vnstat -m -i "$NIC" 2>/dev/null | tail -2 | awk 'NR==2{print $4,$5}' || echo "—")
  _send "📊 *Reporte Diario — $(hostname)*
✅ Activos: ${RUNNING}
💾 Disco: ${DISK_I}
📤 Egreso mes: ${BW_OUT}
🌐 IP: \`${IP}\`
⏱ $(uptime -p)"
  echo "$TODAY" > "$SF"
}
MON
  chmod +x "${BASE}/scripts/tg_monitor.sh"
}

case "${1:-setup}" in
  setup) setup ;;
  test)
    source "$TG_CFG" 2>/dev/null || { echo "Sin config — ejecuta: bash setup_telegram.sh setup"; exit 1; }
    send_tg "🧪 Test manual desde \`$(hostname)\` — $(date '+%H:%M')"
    echo -e "${G}✓ Mensaje enviado${N}" ;;
  *) echo "Uso: $0 [setup|test]" ;;
esac
