#!/usr/bin/env bash
# =============================================================================
#  bwctl — Bandwidth Stack CLI v3
#  Uso: bwctl [status|logs|restart|stop|start|bandwidth|healthcheck|update|info]
# =============================================================================
BASE="/opt/bwstack"
CFG="${BASE}/config/.env"
LOG="${BASE}/logs"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

[[ -f "$CFG" ]] && source "$CFG" 2>/dev/null || true

SERVICES=("bwstack-mysterium" "bwstack-traffmonetizer" "bwstack-repocket"
          "bwstack-bitping" "bwstack-ui")

_svc_name() {
  echo "$1" | sed 's/bwstack-//'
}

# ─── STATUS ──────────────────────────────────────────────────────────────────
cmd_status() {
  echo -e "\n${BLD}${CYN}  ════════════════════════════════════════${NC}"
  echo -e "${BLD}${CYN}    BANDWIDTH STACK v3 — Estado${NC}"
  echo -e "${BLD}${CYN}  ════════════════════════════════════════${NC}"
  echo -e "  IP: ${PUBLIC_IP:-$(curl -s --max-time 5 https://api.ipify.org)} | CPUs: ${CPUS:-$(nproc)} | BW: ${BW_MBPS:-$(( $(nproc)*1000 ))} Mbps egreso\n"

  printf "  %-22s %-12s %-20s\n" "SERVICIO" "ESTADO" "PID / UPTIME"
  printf "  %-22s %-12s %-20s\n" "───────────────────" "──────────" "──────────────────"

  for svc in "${SERVICES[@]}"; do
    NAME=$(_svc_name "$svc")
    if systemctl is-active "$svc" &>/dev/null; then
      PID=$(systemctl show -p MainPID --value "$svc" 2>/dev/null || echo "—")
      UPTIME=$(systemctl show -p ActiveEnterTimestamp --value "$svc" 2>/dev/null \
        | awk '{print $2, $3}' || echo "—")
      printf "  ${GRN}●${NC} %-20s ${GRN}%-12s${NC} %s\n" "$NAME" "activo" "PID:$PID"
    elif systemctl is-enabled "$svc" &>/dev/null 2>&1; then
      printf "  ${RED}●${NC} %-20s ${RED}%-12s${NC}\n" "$NAME" "inactivo"
    fi
  done

  # Contenedores Docker extra (PacketShare, ProxyRack)
  for cname in bws-packetshare bws-proxyrack; do
    if docker inspect "$cname" &>/dev/null 2>&1; then
      STATUS=$(docker inspect --format='{{.State.Status}}' "$cname" 2>/dev/null)
      [[ "$STATUS" == "running" ]] \
        && printf "  ${GRN}●${NC} %-20s ${GRN}%-12s${NC} %s\n" "$cname" "activo" "[docker]" \
        || printf "  ${RED}●${NC} %-20s ${RED}%-12s${NC} %s\n" "$cname" "$STATUS" "[docker]"
    fi
  done

  echo ""
  # Uso de recursos del sistema
  CPU_USE=$(top -bn1 | grep "Cpu(s)" | awk '{printf "%.1f", $2+$4}' 2>/dev/null || echo "—")
  MEM_USE=$(free -h | awk 'NR==2{printf "%s/%s", $3,$2}')
  DISK_USE=$(df -h / | awk 'NR==2{printf "%s/%s (%s)", $3,$2,$5}')
  UPTIME=$(uptime -p 2>/dev/null || echo "—")

  echo -e "  ${DIM}CPU: ${CPU_USE}%  MEM: ${MEM_USE}  Disco: ${DISK_USE}  Up: ${UPTIME}${NC}"
  echo ""
}

# ─── LOGS ────────────────────────────────────────────────────────────────────
cmd_logs() {
  local SVC="${1:-all}"
  if [[ "$SVC" == "all" ]]; then
    echo -e "${CYN}Logs de todos los servicios (Ctrl+C para salir):${NC}"
    journalctl -u "bwstack-*" -f --no-hostname -o short-monotonic 2>/dev/null \
      || tail -f "${LOG}"/*.log 2>/dev/null
  else
    journalctl -u "bwstack-${SVC}" -f --no-hostname 2>/dev/null \
      || tail -f "${LOG}/${SVC}.log" 2>/dev/null \
      || echo "Servicio '$SVC' no encontrado"
  fi
}

# ─── RESTART ─────────────────────────────────────────────────────────────────
cmd_restart() {
  local TARGET="${1:-all}"
  if [[ "$TARGET" == "all" ]]; then
    echo -e "${CYN}Reiniciando todos los servicios...${NC}"
    for svc in "${SERVICES[@]}"; do
      systemctl is-enabled "$svc" &>/dev/null 2>&1 || continue
      systemctl restart "$svc" 2>/dev/null && \
        echo -e "  ${GRN}✔${NC} $(_svc_name $svc)" || \
        echo -e "  ${RED}✘${NC} $(_svc_name $svc)"
    done
    docker restart bws-packetshare bws-proxyrack 2>/dev/null || true
  else
    systemctl restart "bwstack-${TARGET}" 2>/dev/null \
      && echo -e "${GRN}✔ ${TARGET} reiniciado${NC}" \
      || echo -e "${RED}✘ Servicio no encontrado: ${TARGET}${NC}"
  fi
}

# ─── START / STOP ─────────────────────────────────────────────────────────────
cmd_start() {
  local SVC="${1:-all}"
  [[ "$SVC" == "all" ]] \
    && for s in "${SERVICES[@]}"; do systemctl start "$s" 2>/dev/null || true; done \
    || systemctl start "bwstack-${SVC}"
  echo -e "${GRN}✔ Iniciado${NC}"
}

cmd_stop() {
  local SVC="${1:-all}"
  [[ "$SVC" == "all" ]] \
    && for s in "${SERVICES[@]}"; do systemctl stop "$s" 2>/dev/null || true; done \
    || systemctl stop "bwstack-${SVC}"
  echo -e "${YLW}⏹ Detenido${NC}"
}

# ─── BANDWIDTH — uso de red en tiempo real ────────────────────────────────────
cmd_bandwidth() {
  NIC=${ORACLE_NIC:-$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}' || echo "eth0")}
  echo -e "${CYN}Monitor de ancho de banda — interfaz: ${NIC} (Ctrl+C para salir)${NC}\n"

  while true; do
    R1=$(cat /sys/class/net/${NIC}/statistics/rx_bytes 2>/dev/null || echo 0)
    T1=$(cat /sys/class/net/${NIC}/statistics/tx_bytes 2>/dev/null || echo 0)
    sleep 1
    R2=$(cat /sys/class/net/${NIC}/statistics/rx_bytes 2>/dev/null || echo 0)
    T2=$(cat /sys/class/net/${NIC}/statistics/tx_bytes 2>/dev/null || echo 0)

    RX_MBS=$(echo "scale=2; ($R2-$R1)*8/1000000" | bc 2>/dev/null || echo "0")
    TX_MBS=$(echo "scale=2; ($T2-$T1)*8/1000000" | bc 2>/dev/null || echo "0")
    MAX_MBS=${BW_MBPS:-1000}

    # Barra de progreso TX
    PCT=$(echo "scale=0; $TX_MBS*50/$MAX_MBS" | bc 2>/dev/null || echo 0)
    [[ "$PCT" -gt 50 ]] 2>/dev/null && PCT=50
    BAR=$(printf '%0.s█' $(seq 1 ${PCT:-0}))
    EMPTY=$(printf '%0.s░' $(seq 1 $((50-${PCT:-0}))))

    printf "\r  ↑ TX: %6.2f Mbps [${GRN}%s${NC}%s] %3d%% de %d Mbps   ↓ RX: %6.2f Mbps" \
      "$TX_MBS" "$BAR" "$EMPTY" "$(echo "$TX_MBS*100/$MAX_MBS" | bc 2>/dev/null || echo 0)" \
      "$MAX_MBS" "$RX_MBS"
  done
}

# ─── HEALTHCHECK — reiniciar caídos ───────────────────────────────────────────
cmd_healthcheck() {
  for svc in "${SERVICES[@]}"; do
    systemctl is-enabled "$svc" &>/dev/null 2>&1 || continue
    if ! systemctl is-active "$svc" &>/dev/null; then
      echo "[$(date '+%H:%M:%S')] Reiniciando $(_svc_name $svc)..."
      systemctl start "$svc" 2>/dev/null || true
    fi
  done
  # Docker
  for cname in bws-packetshare bws-proxyrack; do
    docker inspect "$cname" &>/dev/null 2>&1 || continue
    STATUS=$(docker inspect --format='{{.State.Status}}' "$cname" 2>/dev/null)
    [[ "$STATUS" != "running" ]] && docker start "$cname" 2>/dev/null || true
  done
}

# ─── UPDATE — actualizar binarios ─────────────────────────────────────────────
cmd_update() {
  echo -e "${CYN}Actualizando servicios...${NC}"
  # Actualizar npm packages
  npm update -g @repocket/repocket 2>/dev/null || true
  # Actualizar Docker containers si existen
  for cname in bws-packetshare bws-proxyrack mysterium; do
    docker inspect "$cname" &>/dev/null 2>&1 || continue
    IMG=$(docker inspect --format='{{.Config.Image}}' "$cname")
    docker pull "$IMG" 2>/dev/null && docker restart "$cname" 2>/dev/null || true
    echo -e "  ${GRN}✔${NC} $cname actualizado"
  done
  # Reiniciar servicios systemd tras actualización
  cmd_restart all
  echo -e "${GRN}✔ Actualización completa${NC}"
}

# ─── INFO — información del sistema Oracle ────────────────────────────────────
cmd_info() {
  echo -e "\n${BLD}${CYN}  Sistema Oracle Free Tier${NC}"
  echo -e "  ──────────────────────────────────────────"
  echo -e "  Hostname     : $(hostname)"
  echo -e "  IP pública   : ${PUBLIC_IP:-$(curl -s --max-time 5 https://api.ipify.org)}"
  echo -e "  Arquitectura : $(uname -m) ($(uname -r))"
  echo -e "  CPUs         : $(nproc) OCPUs"
  echo -e "  RAM          : $(free -h | awk 'NR==2{print $2}') total | $(free -h | awk 'NR==2{print $7}') libre"
  echo -e "  Disco        : $(df -h / | awk 'NR==2{printf \"%s/%s (%s)\", $3,$2,$5}')"
  echo -e "  Uptime       : $(uptime -p)"
  echo -e ""
  echo -e "  Egreso máx   : $(($(nproc) * 1000)) Mbps (1 Gbps × $(nproc) OCPU)"
  echo -e "  Ingreso      : Ilimitado"
  echo -e "  Egreso gratis: 10 TB/mes por cuenta Oracle"
  echo -e ""
  NIC=${ORACLE_NIC:-$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}' || echo "eth0")}
  echo -e "  Interfaz NIC : ${NIC}"
  echo -e "  MTU          : $(ip link show $NIC 2>/dev/null | awk '/mtu/{print $5}' || echo '—')"
  echo -e "  TCP CC       : $(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)"
  echo -e ""
}

# ─── HELP ────────────────────────────────────────────────────────────────────
cmd_help() {
  echo -e "\n${BLD}bwctl${NC} — Bandwidth Stack v3 CLI\n"
  echo -e "  ${CYN}bwctl status${NC}              Estado de todos los servicios"
  echo -e "  ${CYN}bwctl logs [servicio]${NC}     Logs en tiempo real"
  echo -e "  ${CYN}bwctl restart [svc|all]${NC}   Reiniciar servicio(s)"
  echo -e "  ${CYN}bwctl start [svc|all]${NC}     Iniciar servicio(s)"
  echo -e "  ${CYN}bwctl stop [svc|all]${NC}      Detener servicio(s)"
  echo -e "  ${CYN}bwctl bandwidth${NC}           Monitor de ancho de banda en vivo"
  echo -e "  ${CYN}bwctl healthcheck${NC}         Verificar y reiniciar caídos"
  echo -e "  ${CYN}bwctl update${NC}              Actualizar todos los binarios"
  echo -e "  ${CYN}bwctl info${NC}                Info del sistema Oracle"
  echo -e "\n  Servicios: mysterium | traffmonetizer | repocket | bitping | ui\n"
}

# ─── DISPATCHER ───────────────────────────────────────────────────────────────
case "${1:-status}" in
  status)      cmd_status ;;
  logs)        cmd_logs "${2:-all}" ;;
  restart)     cmd_restart "${2:-all}" ;;
  start)       cmd_start "${2:-all}" ;;
  stop)        cmd_stop "${2:-all}" ;;
  bandwidth|bw) cmd_bandwidth ;;
  healthcheck) cmd_healthcheck ;;
  update)      cmd_update ;;
  info)        cmd_info ;;
  help|--help|-h) cmd_help ;;
  *) echo -e "${RED}Comando desconocido: $1${NC}"; cmd_help ;;
esac
