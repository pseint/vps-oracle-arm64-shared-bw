#!/usr/bin/env bash
# =============================================================================
#  ARM64 Ampere A1 — Instalador Completo v2.2 FIXED
#  FIXES: rutas planas, web UI path, test duplicado removido
# =============================================================================
set -euo pipefail; IFS=$'\n\t'

# Directorio del script (estructura plana — todos en mismo dir)
STACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
C='\033[0;36m'; B='\033[1m'; D='\033[2m'; N='\033[0m'
log()  { echo -e "${G}[✔]${N} $*"; }
warn() { echo -e "${Y}[⚠]${N} $*"; }
err()  { echo -e "${R}[✘]${N} $*" >&2; }
hdr()  { echo -e "\n${B}${C}══════════════════════════════════════${N}"; \
         echo -e "${B}${C}  $*${N}"; \
         echo -e "${B}${C}══════════════════════════════════════${N}\n"; }
step() { echo -e "  ${C}→${N} $*"; }

BASE="/opt/bwstack"
CFG="${BASE}/config"
BIN="${BASE}/bin"
LOGS="${BASE}/logs"
DATA="${BASE}/data"
WEB="${BASE}/web"
SYSTEMD="/etc/systemd/system"
ENV_FILE="${CFG}/.env"
INSTALL_LOG="${LOGS}/install.log"

# ── Preflight ─────────────────────────────────────────────────────────────────
preflight() {
  hdr "VERIFICACIONES PREVIAS"
  [[ $EUID -ne 0 ]] && { err "Requiere root"; exit 1; }

  ARCH=$(uname -m)
  CPUS=$(nproc)
  RAM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
  RAM_GB=$(awk '/MemTotal/{printf "%.1f",$2/1024/1024}' /proc/meminfo)
  PUBLIC_IP=$(curl -s --max-time 8 https://api.ipify.org 2>/dev/null \
           || curl -s --max-time 8 https://ifconfig.me 2>/dev/null \
           || echo "UNKNOWN")
  BW_MBPS=$((CPUS * 1000))
  HOSTNAME_ID=$(hostname | tr -d ' ')

  log "Arquitectura : $ARCH"
  log "CPUs         : $CPUS OCPU → ${BW_MBPS} Mbps egreso"
  log "RAM          : ${RAM_GB} GB"
  log "IP pública   : $PUBLIC_IP"

  warn "ORACLE — Límites reales:"
  echo "  • Egreso: 1 Gbps × nº OCPUs de ESTA instancia"
  echo "  • 10 TB/mes saliente por CUENTA (compartido entre instancias)"
  echo "  • Entrada: ilimitada y gratis"
}

# ── Directorios ───────────────────────────────────────────────────────────────
make_dirs() {
  mkdir -p "$BIN" "$CFG" "$LOGS" "$WEB" \
    "${DATA}/mysterium" "${DATA}/bitping" "${DATA}/repocket" \
    "${BASE}/services"
  chmod 700 "$CFG"
  mkdir -p "$(dirname "$INSTALL_LOG")"
  touch "$INSTALL_LOG"
  exec > >(tee -a "$INSTALL_LOG") 2>&1
  log "Directorios en $BASE ✓"
}

# ── Sistema base ──────────────────────────────────────────────────────────────
install_deps() {
  hdr "SISTEMA Y DEPENDENCIAS"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get upgrade -y -qq \
    -o Dpkg::Options::="--force-confdef" \
    -o Dpkg::Options::="--force-confold" 2>/dev/null

  apt-get install -y -qq \
    curl wget ca-certificates gnupg lsb-release \
    apt-transport-https software-properties-common \
    net-tools jq unzip cron logrotate \
    iptables netfilter-persistent iptables-persistent \
    python3 ethtool iproute2 bc vnstat 2>/dev/null || true

  # Node.js 20 LTS
  NODE_VER=$(node -v 2>/dev/null | sed 's/v//;s/\..*//' || echo 0)
  if [[ "$NODE_VER" -lt 18 ]]; then
    step "Instalando Node.js 20 LTS..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - 2>/dev/null
    apt-get install -y -qq nodejs
  fi
  log "Dependencias OK (Node $(node -v 2>/dev/null)) ✓"
}

# ── Docker mínimo (solo PacketShare/ProxyRack) ────────────────────────────────
install_docker_minimal() {
  command -v docker &>/dev/null && { log "Docker ya presente ✓"; return; }
  step "Instalando Docker..."
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg 2>/dev/null
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
    | tee /etc/apt/sources.list.d/docker.list > /dev/null
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
  cat > /etc/docker/daemon.json << 'DD'
{"log-driver":"json-file","log-opts":{"max-size":"5m","max-file":"2"},"live-restore":true}
DD
  systemctl enable --now docker
  log "Docker instalado ✓"
}

# ── FIX: UFW + Oracle iptables (sin -F) ──────────────────────────────────────
fix_firewall() {
  hdr "FIREWALL (Oracle-safe)"
  # Desactivar UFW
  if systemctl is-active ufw &>/dev/null || systemctl is-enabled ufw &>/dev/null 2>/dev/null; then
    ufw --force disable 2>/dev/null || true
    systemctl disable ufw 2>/dev/null || true
    log "UFW desactivado ✓"
  fi
  # Backup reglas Oracle
  iptables-save > "${CFG}/iptables-oracle-backup.rules" 2>/dev/null || true

  # Añadir SIN vaciar (-C check antes de -A)
  _ar() { iptables -C "$@" 2>/dev/null || iptables -A "$@"; }
  _ar INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
  _ar INPUT -i lo -j ACCEPT
  _ar INPUT -p tcp --dport 22   -j ACCEPT
  _ar INPUT -p tcp --dport 4449 -j ACCEPT
  _ar INPUT -p tcp --dport 59850:60000 -j ACCEPT
  _ar INPUT -p udp --dport 59850:60000 -j ACCEPT
  _ar INPUT -p tcp --dport 8080 -j ACCEPT
  _ar FORWARD -i docker0 -j ACCEPT
  _ar FORWARD -o docker0 -j ACCEPT

  netfilter-persistent save 2>/dev/null \
    || iptables-save > /etc/iptables/rules.v4 2>/dev/null || true
  log "Puertos abiertos (reglas Oracle preservadas) ✓"

  warn "ORACLE VCN — Comprueba que la fuente sea 0.0.0.0/0 (NO 10.0.0.0/24):"
  echo "  La captura muestra source 10.0.0.0/24 = solo LAN interna"
  echo "  Debes cambiar a 0.0.0.0/0 para acceso desde internet"
  echo "  Oracle Console → VCN → Security Lists → editar reglas → Source: 0.0.0.0/0"
}

# ── Optimizar kernel ──────────────────────────────────────────────────────────
optimize_kernel() {
  hdr "OPTIMIZACIÓN DE RED ARM64"
  grep -q "bwstack" /etc/sysctl.conf 2>/dev/null && { log "Kernel ya optimizado ✓"; return; }

  NIC=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}' || echo "eth0")
  # Guardar NIC
  grep -q "ORACLE_NIC" "${ENV_FILE}" 2>/dev/null \
    || echo "ORACLE_NIC=${NIC}" >> "${ENV_FILE}"

  cat >> /etc/sysctl.conf << SYSCTL

# bwstack ARM64 v2.2
net.core.rmem_max                = 268435456
net.core.wmem_max                = 268435456
net.core.rmem_default            = 131072
net.core.wmem_default            = 131072
net.ipv4.tcp_rmem                = 4096 131072 268435456
net.ipv4.tcp_wmem                = 4096 131072 268435456
net.core.default_qdisc           = fq
net.ipv4.tcp_congestion_control  = bbr
net.core.somaxconn               = 65535
net.ipv4.tcp_max_syn_backlog     = 65535
net.core.netdev_max_backlog      = 65535
net.ipv4.tcp_tw_reuse            = 1
net.ipv4.tcp_fin_timeout         = 15
net.ipv4.ip_local_port_range     = 1024 65535
net.ipv4.ip_forward              = 1
net.ipv6.conf.all.forwarding     = 1
fs.file-max                      = 2000000
# end bwstack
SYSCTL

  modprobe tcp_bbr 2>/dev/null || true
  sysctl -p /etc/sysctl.conf 2>/dev/null || true

  cat >> /etc/security/limits.conf << 'LIM'
* soft nofile 1000000
* hard nofile 1000000
root soft nofile 1000000
root hard nofile 1000000
LIM

  ethtool -G "$NIC" rx 4096 tx 4096 2>/dev/null || true
  ethtool -K "$NIC" gro on gso on tso on 2>/dev/null || true
  log "TCP BBR + buffers 256MB + NIC offloads ($NIC) ✓"
}

# ── Credenciales ──────────────────────────────────────────────────────────────
collect_creds() {
  hdr "CONFIGURACIÓN DE PROVEEDORES"

  if [[ -f "$ENV_FILE" ]] && grep -q "USE_MYSTERIUM" "$ENV_FILE" 2>/dev/null; then
    warn "Config existente detectada"
    read -rp "  ¿Reconfigurar? [s/N]: " RC
    [[ "${RC,,}" != "s" ]] && { source "$ENV_FILE"; return; }
  fi

  echo -e "${Y}Deja VACÍO los que no uses.${N}\n"

  printf "${C}┌─ 1/6 MYSTERIUM${N} (mystnodes.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | MYST crypto | Configura en http://IP:4449\n"
  read -rp "└─ ¿Activar? [S/n]: " _M; USE_MYSTERIUM="${_M:-S}"

  printf "\n${C}┌─ 2/6 TRAFFMONETIZER${N} (traffmonetizer.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | BTC | Token en tu dashboard\n"
  read -rp "└─ Token (vacío=omitir): " TM_TOKEN

  printf "\n${C}┌─ 3/6 REPOCKET${N} (repocket.co)\n"
  printf "${C}│${N}  Acepta VPS ✓ | PayPal/Wise\n"
  read -rp "└─ Email (vacío=omitir): " RP_EMAIL
  RP_API_KEY=""
  [[ -n "${RP_EMAIL:-}" ]] && read -rp "  API Key: " RP_API_KEY

  printf "\n${C}┌─ 4/6 BITPING${N} (bitping.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | SOL (Solana)\n"
  read -rp "└─ Email (vacío=omitir): " BP_EMAIL
  BP_PASSWORD=""
  [[ -n "${BP_EMAIL:-}" ]] && { read -rsp "  Password: " BP_PASSWORD; echo; }

  printf "\n${C}┌─ 5/6 PACKETSHARE${N} (packetshare.io)\n"
  printf "${C}│${N}  Acepta VPS ✓ | PayPal\n"
  read -rp "└─ Email (vacío=omitir): " PS_EMAIL
  PS_PASSWORD=""
  [[ -n "${PS_EMAIL:-}" ]] && { read -rsp "  Password: " PS_PASSWORD; echo; }

  printf "\n${C}┌─ 6/6 PROXYRACK${N} (peer.proxyrack.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | PayPal\n"
  read -rp "└─ API Key (vacío=omitir): " PR_API_KEY

  cat > "$ENV_FILE" << EOF
# Bandwidth Stack v2.2 — $(date)
PUBLIC_IP=${PUBLIC_IP}
ARCH=${ARCH}
CPUS=${CPUS}
BW_MBPS=${BW_MBPS}
HOSTNAME_ID=${HOSTNAME_ID}
INSTANCE_TYPE=ampere
ORACLE_NIC=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}' || echo eth0)

USE_MYSTERIUM=${USE_MYSTERIUM^^}
TM_TOKEN=${TM_TOKEN:-}
RP_EMAIL=${RP_EMAIL:-}
RP_API_KEY=${RP_API_KEY:-}
BP_EMAIL=${BP_EMAIL:-}
BP_PASSWORD=${BP_PASSWORD:-}
PS_EMAIL=${PS_EMAIL:-}
PS_PASSWORD=${PS_PASSWORD:-}
PR_API_KEY=${PR_API_KEY:-}
DEVICE_NAME=oracle-${HOSTNAME_ID}
EOF
  chmod 600 "$ENV_FILE"
  source "$ENV_FILE"
  log "Credenciales guardadas ✓"
}

# ── 1. Mysterium ──────────────────────────────────────────────────────────────
install_mysterium() {
  [[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] || { step "Mysterium: omitido"; return; }
  hdr "1/6 MYSTERIUM (nativo ARM64)"

  if [[ ! -f "${BIN}/myst" ]]; then
    step "Descargando myst ARM64..."
    MYST_VER=$(curl -s https://api.github.com/repos/mysteriumnetwork/node/releases/latest \
      | jq -r '.tag_name' 2>/dev/null || echo "latest")
    curl -SL "https://github.com/mysteriumnetwork/node/releases/download/${MYST_VER}/myst_linux_arm64.tar.gz" \
      -o /tmp/myst.tar.gz 2>/dev/null || {
        warn "Descarga fallida → Docker fallback"
        install_docker_minimal
        docker rm -f bws-mysterium 2>/dev/null || true
        docker run -d --name bws-mysterium --restart=unless-stopped \
          --cap-add NET_ADMIN --network=host \
          -v "${DATA}/mysterium:/var/lib/mysterium-node" \
          mysteriumnetwork/myst:latest \
          --udp.ports=59850:60000 service --agreed-terms-and-conditions 2>/dev/null || true
        log "Mysterium via Docker ✓"; return
      }
    tar -xzf /tmp/myst.tar.gz -C "$BIN" 2>/dev/null || true
    [[ -f "${BIN}/myst" ]] || { warn "No se extrajo myst"; rm -f /tmp/myst.tar.gz; return; }
    chmod +x "${BIN}/myst"
    rm -f /tmp/myst.tar.gz
  fi

  useradd -r -s /bin/false myst 2>/dev/null || true
  chown -R myst:myst "${DATA}/mysterium" 2>/dev/null || true

  cat > "${SYSTEMD}/bwstack-mysterium.service" << MYST
[Unit]
Description=Mysterium Network Node
After=network-online.target
Wants=network-online.target

[Service]
User=myst
Group=myst
ExecStart=${BIN}/myst \\
  --data-dir=${DATA}/mysterium \\
  --ui.enable=true \\
  --ui.port=4449 \\
  --udp.ports=59850:60000 \\
  service \\
  --agreed-terms-and-conditions
Restart=always
RestartSec=10
LimitNOFILE=1000000
StandardOutput=append:${LOGS}/mysterium.log
StandardError=append:${LOGS}/mysterium.log

[Install]
WantedBy=multi-user.target
MYST

  systemctl daemon-reload
  systemctl enable --now bwstack-mysterium.service
  log "Mysterium nativo ARM64 → http://${PUBLIC_IP}:4449 ✓"
}

# ── 2. Traffmonetizer ─────────────────────────────────────────────────────────
install_traffmonetizer() {
  [[ -n "${TM_TOKEN:-}" ]] || { step "Traffmonetizer: omitido"; return; }
  hdr "2/6 TRAFFMONETIZER"

  TM_BIN="${BIN}/traffmonetizer"
  if [[ ! -f "$TM_BIN" ]]; then
    curl -SL "https://traffmonetizer.com/files/cli_v2/linux/arm64/traffmonetizer" \
      -o "$TM_BIN" 2>/dev/null && chmod +x "$TM_BIN" || {
        warn "Binario no disponible → Docker mínimo"
        install_docker_minimal
        cat > "${BASE}/services/tm.yml" << TMDKR
version: "3.8"
services:
  traffmonetizer:
    image: traffmonetizer/cli_v2:latest
    restart: unless-stopped
    command: start accept --token ${TM_TOKEN}
    network_mode: host
    mem_limit: 80m
    logging:
      driver: json-file
      options: {max-size: "5m", max-file: "2"}
TMDKR
        docker compose -f "${BASE}/services/tm.yml" up -d 2>/dev/null || true
        log "Traffmonetizer Docker mínimo ✓"; return
      }
  fi

  cat > "${SYSTEMD}/bwstack-traffmonetizer.service" << TM
[Unit]
Description=Traffmonetizer
After=network-online.target

[Service]
ExecStart=${TM_BIN} start accept --token ${TM_TOKEN}
Restart=always
RestartSec=15
LimitNOFILE=100000
StandardOutput=append:${LOGS}/traffmonetizer.log
StandardError=append:${LOGS}/traffmonetizer.log

[Install]
WantedBy=multi-user.target
TM

  systemctl daemon-reload
  systemctl enable --now bwstack-traffmonetizer.service
  log "Traffmonetizer nativo ✓"
}

# ── 3. Repocket ───────────────────────────────────────────────────────────────
install_repocket() {
  [[ -n "${RP_EMAIL:-}" ]] && [[ -n "${RP_API_KEY:-}" ]] || { step "Repocket: omitido"; return; }
  hdr "3/6 REPOCKET (npm)"

  npm install -g @repocket/repocket 2>/dev/null \
    || { warn "npm install falló — instala manualmente: npm i -g @repocket/repocket"; return; }

  RP_BIN=$(command -v repocket 2>/dev/null || echo "/usr/local/bin/repocket")
  [[ ! -f "$RP_BIN" ]] && { warn "Repocket no instalado"; return; }

  cat > "${SYSTEMD}/bwstack-repocket.service" << RP
[Unit]
Description=Repocket
After=network-online.target

[Service]
Environment=RP_EMAIL=${RP_EMAIL}
Environment=RP_API_KEY=${RP_API_KEY}
ExecStart=${RP_BIN}
Restart=always
RestartSec=15
LimitNOFILE=100000
StandardOutput=append:${LOGS}/repocket.log
StandardError=append:${LOGS}/repocket.log

[Install]
WantedBy=multi-user.target
RP

  systemctl daemon-reload
  systemctl enable --now bwstack-repocket.service
  log "Repocket (npm) ✓"
}

# ── 4. Bitping ────────────────────────────────────────────────────────────────
install_bitping() {
  [[ -n "${BP_EMAIL:-}" ]] && [[ -n "${BP_PASSWORD:-}" ]] || { step "Bitping: omitido"; return; }
  hdr "4/6 BITPING (nativo ARM64)"

  if [[ ! -f "${BIN}/bitpingd" ]]; then
    BP_URL=$(curl -s https://api.github.com/repos/bitping/bitpingd/releases/latest \
      | jq -r '.assets[]|select(.name|test("linux.*arm64"))|.browser_download_url' \
      2>/dev/null | head -1)
    [[ -n "${BP_URL:-}" ]] \
      && curl -SL "$BP_URL" -o "${BIN}/bitpingd" 2>/dev/null && chmod +x "${BIN}/bitpingd" \
      || { warn "Bitping: descarga fallida — omitiendo"; return; }
  fi

  cat > "${SYSTEMD}/bwstack-bitping.service" << BP
[Unit]
Description=Bitping
After=network-online.target

[Service]
Environment=BITPING_EMAIL=${BP_EMAIL}
Environment=BITPING_PASSWORD=${BP_PASSWORD}
ExecStart=${BIN}/bitpingd --data-directory=${DATA}/bitping
Restart=always
RestartSec=20
LimitNOFILE=100000
StandardOutput=append:${LOGS}/bitping.log
StandardError=append:${LOGS}/bitping.log

[Install]
WantedBy=multi-user.target
BP

  systemctl daemon-reload
  systemctl enable --now bwstack-bitping.service
  log "Bitping nativo ARM64 ✓"
}

# ── 5+6. PacketShare + ProxyRack ──────────────────────────────────────────────
install_docker_services() {
  hdr "5+6: PACKETSHARE + PROXYRACK (Docker)"
  install_docker_minimal

  if [[ -n "${PS_EMAIL:-}" ]] && [[ -n "${PS_PASSWORD:-}" ]]; then
    docker rm -f bws-packetshare 2>/dev/null || true
    docker run -d --name bws-packetshare \
      --restart=unless-stopped --network=host --memory=80m \
      --log-opt max-size=5m --log-opt max-file=2 \
      packetshare/packetshare:latest \
      -accept-tos -email="${PS_EMAIL}" -password="${PS_PASSWORD}" 2>/dev/null \
      && log "PacketShare ✓" || warn "PacketShare: verificar"
  else
    step "PacketShare: omitido"
  fi

  if [[ -n "${PR_API_KEY:-}" ]]; then
    docker rm -f bws-proxyrack 2>/dev/null || true
    docker run -d --name bws-proxyrack \
      --restart=unless-stopped --network=host --memory=80m \
      --log-opt max-size=5m --log-opt max-file=2 \
      -e API_KEY="${PR_API_KEY}" \
      -e DEVICE_NAME="${DEVICE_NAME:-oracle-$(hostname)}" \
      proxyrack/peer:latest 2>/dev/null \
      && log "ProxyRack ✓" || warn "ProxyRack: verificar"
  else
    step "ProxyRack: omitido"
  fi
}

# ── Web UI — FIX: busca server.py en mismo directorio (estructura plana) ───────
install_webui() {
  hdr "WEB UI (puerto 8080)"

  # FIXED: buscar server.py en el mismo directorio del script (estructura plana)
  WEB_SRC="${STACK_DIR}/server.py"

  if [[ ! -f "$WEB_SRC" ]]; then
    warn "server.py no encontrado en ${STACK_DIR}"
    warn "Web UI desactivado — copia server.py al directorio del proyecto"
    return
  fi

  mkdir -p "$WEB"
  cp "$WEB_SRC" "${WEB}/server.py"
  log "server.py copiado a ${WEB}/server.py ✓"

  cat > "${SYSTEMD}/bwstack-ui.service" << UI
[Unit]
Description=Bandwidth Stack Web UI
After=network-online.target

[Service]
ExecStart=/usr/bin/python3 ${WEB}/server.py
WorkingDirectory=${WEB}
Restart=always
RestartSec=5
Environment=BW_BASE=${BASE}
Environment=PORT=8080
StandardOutput=append:${LOGS}/webui.log
StandardError=append:${LOGS}/webui.log

[Install]
WantedBy=multi-user.target
UI

  systemctl daemon-reload
  systemctl enable --now bwstack-ui.service
  log "Web UI → http://${PUBLIC_IP}:8080 ✓"
}

# ── bwctl CLI — FIX: buscar en mismo directorio ───────────────────────────────
install_bwctl() {
  BWCTL_SRC="${STACK_DIR}/bwctl.sh"
  if [[ -f "$BWCTL_SRC" ]]; then
    cp "$BWCTL_SRC" /usr/local/bin/bwctl
    chmod +x /usr/local/bin/bwctl
    log "CLI 'bwctl' instalado ✓"
  else
    warn "bwctl.sh no encontrado en ${STACK_DIR}"
  fi
}

# ── Systemd target ────────────────────────────────────────────────────────────
install_systemd_target() {
  cat > "${SYSTEMD}/bwstack.target" << 'TARGET'
[Unit]
Description=Bandwidth Stack
After=network-online.target docker.service
Wants=bwstack-mysterium.service bwstack-traffmonetizer.service
Wants=bwstack-repocket.service bwstack-bitping.service bwstack-ui.service

[Install]
WantedBy=multi-user.target
TARGET
  systemctl daemon-reload
  systemctl enable bwstack.target
  log "Systemd target ✓"
}

# ── Mantenimiento ─────────────────────────────────────────────────────────────
setup_maintenance() {
  cat > /etc/logrotate.d/bwstack << LR
${LOGS}/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0644 root root
}
LR
  systemctl enable --now vnstat 2>/dev/null || true
  NIC=$(grep "ORACLE_NIC" "${ENV_FILE}" 2>/dev/null | cut -d= -f2 || echo eth0)
  vnstat -i "$NIC" 2>/dev/null || true

  CTMP=$(mktemp)
  crontab -l 2>/dev/null | grep -v bwstack > "$CTMP" || true
  echo "*/5 * * * * /usr/local/bin/bwctl healthcheck >> ${LOGS}/cron.log 2>&1" >> "$CTMP"
  echo "0 4 * * 0 /usr/local/bin/bwctl update >> ${LOGS}/update.log 2>&1" >> "$CTMP"
  crontab "$CTMP"; rm "$CTMP"
  log "Logrotate + cron + vnstat ✓"
}

# ── Test suite — FIX: removido test duplicado root/sudo ───────────────────────
run_tests() {
  hdr "TEST SUITE — VERIFICACIÓN FINAL"
  source "$ENV_FILE" 2>/dev/null || true
  P=0; F=0
  _ok()   { echo -e "  ${G}[PASS]${N} $1"; ((P++)); }
  _fail() { echo -e "  ${R}[FAIL]${N} $1  ${R}← $2${N}"; ((F++)); }
  _t()    { eval "$2" &>/dev/null && _ok "$1" || _fail "$1" "${3:-revisar}"; }

  echo "── Sistema ──"
  # FIX: solo UN test de root (removido el duplicado)
  _t "Ejecutando como root"     "[[ \$EUID -eq 0 ]]" "sudo bash install.sh"
  _t "IP forwarding"            "[[ \$(cat /proc/sys/net/ipv4/ip_forward) == 1 ]]" "sysctl -w net.ipv4.ip_forward=1"
  _t "TCP BBR activo"           "sysctl net.ipv4.tcp_congestion_control | grep -q bbr" "modprobe tcp_bbr"
  _t "UFW inactivo"             "! systemctl is-active ufw 2>/dev/null" "ufw disable"
  _t "ulimit nofile ≥100k"      "[[ \$(ulimit -Hn 2>/dev/null || echo 0) -ge 100000 ]]" "/etc/security/limits.conf"
  _t "Node.js ≥18"              "node -v 2>/dev/null | grep -qE 'v(1[89]|[2-9][0-9])'" "reinstalar nodejs"
  _t "server.py instalado"      "[[ -f ${WEB}/server.py ]]" "verificar server.py en directorio del proyecto"

  echo ""
  echo "── Servicios ──"
  [[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] && \
    _t "Mysterium activo"     "systemctl is-active bwstack-mysterium 2>/dev/null || docker ps 2>/dev/null | grep -q bws-mysterium" "bwctl restart mysterium"
  [[ -n "${TM_TOKEN:-}" ]] && \
    _t "Traffmonetizer activo" "systemctl is-active bwstack-traffmonetizer 2>/dev/null || docker ps 2>/dev/null | grep -q traffmonetizer" "bwctl restart traffmonetizer"
  [[ -n "${RP_EMAIL:-}" ]] && \
    _t "Repocket activo"      "systemctl is-active bwstack-repocket" "bwctl restart repocket"
  [[ -n "${BP_EMAIL:-}" ]] && \
    _t "Bitping activo"       "systemctl is-active bwstack-bitping" "bwctl restart bitping"
  [[ -n "${PS_EMAIL:-}" ]] && \
    _t "PacketShare activo"   "docker ps 2>/dev/null | grep -q bws-packetshare" "docker start bws-packetshare"
  [[ -n "${PR_API_KEY:-}" ]] && \
    _t "ProxyRack activo"     "docker ps 2>/dev/null | grep -q bws-proxyrack" "docker start bws-proxyrack"
  _t "Web UI activo"          "systemctl is-active bwstack-ui" "bwctl restart ui"

  echo ""
  echo "── Red ──"
  _t "Puerto 8080 (Dashboard)"    "ss -tlnp | grep -q ':8080'" "bwctl restart ui"
  [[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] && \
    _t "Puerto 4449 (Mysterium)"  "ss -tlnp | grep -q ':4449'" "bwctl restart mysterium"
  _t "Conectividad internet"      "curl -s --max-time 5 https://1.1.1.1 -o /dev/null" "verificar red"

  echo ""
  echo "── Archivos ──"
  _t "config/.env existe"         "[[ -f ${ENV_FILE} ]]" "ejecutar install.sh"
  _t "bwctl instalado"            "command -v bwctl" "cp bwctl.sh /usr/local/bin/bwctl && chmod +x /usr/local/bin/bwctl"
  _t "Cron healthcheck"           "crontab -l 2>/dev/null | grep -q bwstack" "ejecutar install.sh"

  echo ""
  echo -e "  ────────────────────────────────────"
  echo -e "  ${G}${P} PASS${N}  ${R}${F} FAIL${N}"
  [[ $F -eq 0 ]] \
    && echo -e "\n  ${G}${B}✅ Stack listo para producción${N}" \
    || echo -e "\n  ${R}Corrige los FAIL antes de producción${N}"
}

# ── Resumen ───────────────────────────────────────────────────────────────────
show_summary() {
  source "$ENV_FILE" 2>/dev/null || true
  hdr "✅ INSTALACIÓN v2.2 COMPLETADA"
  echo -e "  IP pública   : ${B}${PUBLIC_IP}${N}"
  echo -e "  Egreso máx.  : ${B}${BW_MBPS} Mbps${N} (${CPUS} OCPU × 1 Gbps)"
  echo -e "  Ingreso      : Ilimitado"
  echo ""
  echo -e "  ${B}Paneles:${N}"
  [[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] && \
    echo -e "  • Mysterium UI : ${C}http://${PUBLIC_IP}:4449${N}"
  echo -e "  • Dashboard    : ${C}http://${PUBLIC_IP}:8080${N}"
  echo ""
  echo -e "  ${B}CLI:${N}  bwctl status | bwctl logs | bwctl bandwidth | bwctl restart all"
  echo ""
  echo -e "  ${R}${B}⚠ ORACLE VCN — ACCIÓN CRÍTICA:${N}"
  echo -e "  Tus reglas actuales tienen Source: ${R}10.0.0.0/24${N} (solo LAN)"
  echo -e "  Cambia a Source: ${G}0.0.0.0/0${N} para acceso desde internet"
  echo -e "  Oracle Console → VCN → Security Lists → editar cada regla"
}

# ── MAIN ──────────────────────────────────────────────────────────────────────
main() {
  preflight
  make_dirs
  install_deps
  fix_firewall
  optimize_kernel
  collect_creds
  install_mysterium
  install_traffmonetizer
  install_repocket
  install_bitping
  install_docker_services
  install_webui
  install_bwctl
  install_systemd_target
  setup_maintenance
  sleep 3
  run_tests
  show_summary
}

main "$@"
