#!/usr/bin/env bash
# =============================================================================
#  ARM64 Ampere A1 — Instalador Completo v2.1
#  6 proveedores · Nativo systemd · Sin Docker overhead
#  Oracle Free Tier · Ubuntu 22.04 arm64
# =============================================================================
set -euo pipefail; IFS=$'\n\t'

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
C='\033[0;36m'; B='\033[1m'; D='\033[2m'; N='\033[0m'

log()   { echo -e "${G}[✔]${N} $*"; }
warn()  { echo -e "${Y}[⚠]${N} $*"; }
err()   { echo -e "${R}[✘]${N} $*" >&2; }
hdr()   { echo -e "\n${B}${C}══════════════════════════════════════${N}"; \
          echo -e "${B}${C}  $*${N}"; \
          echo -e "${B}${C}══════════════════════════════════════${N}\n"; }
step()  { echo -e "  ${C}→${N} $*"; }

BASE="/opt/bwstack"
CFG="${BASE}/config"
BIN="${BASE}/bin"
LOGS="${BASE}/logs"
DATA="${BASE}/data"
WEB="${BASE}/web"
SYSTEMD="/etc/systemd/system"
ENV_FILE="${CFG}/.env"
INSTALL_LOG="${LOGS}/install.log"

# ── Preflight ─────────────────────────────────────────────────────────────────
preflight() {
  hdr "VERIFICACIONES PREVIAS"
  [[ $EUID -ne 0 ]] && { err "Requiere root"; exit 1; }

  ARCH=$(uname -m)
  CPUS=$(nproc)
  RAM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
  RAM_GB=$(awk '/MemTotal/{printf "%.1f",$2/1024/1024}' /proc/meminfo)
  PUBLIC_IP=$(curl -s --max-time 8 https://api.ipify.org \
           || curl -s --max-time 8 https://ifconfig.me \
           || echo "UNKNOWN")
  BW_MBPS=$((CPUS * 1000))
  HOSTNAME_ID=$(hostname | tr -d ' ')

  log "Arquitectura : $ARCH"
  log "CPUs         : $CPUS OCPU → ${BW_MBPS} Mbps egreso"
  log "RAM          : ${RAM_GB} GB"
  log "IP pública   : $PUBLIC_IP"
  log "Ingreso red  : Ilimitado (Oracle no cobra ingreso)"
  echo ""
  warn "ORACLE FREE TIER — Límites reales:"
  echo "  • Egreso: 1 Gbps × nº OCPUs de ESTA instancia"
  echo "  • 10 TB/mes saliente por CUENTA (no por instancia)"
  echo "  • Entrada: ilimitada y gratis"
  echo "  • Para 4 IPs distintas: crear 4 instancias de 1 OCPU c/u"
}

# ── Directorios ───────────────────────────────────────────────────────────────
make_dirs() {
  mkdir -p "$BIN" "$CFG" "$LOGS" "$WEB" \
    "${DATA}/mysterium" "${DATA}/bitping" "${DATA}/repocket" \
    "${BASE}/services" "${BASE}/scripts" "${BASE}/backups"
  chmod 700 "$CFG"
  exec > >(tee -a "$INSTALL_LOG") 2>&1
  log "Directorios en $BASE ✓"
}

# ── Sistema base ──────────────────────────────────────────────────────────────
install_deps() {
  hdr "SISTEMA Y DEPENDENCIAS"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get upgrade -y -qq \
    -o Dpkg::Options::="--force-confdef" \
    -o Dpkg::Options::="--force-confold" 2>/dev/null

  apt-get install -y -qq \
    curl wget ca-certificates gnupg lsb-release \
    apt-transport-https software-properties-common \
    net-tools jq unzip cron logrotate \
    iptables netfilter-persistent iptables-persistent \
    python3 ethtool iproute2 bc vnstat 2>/dev/null || true

  # Node.js 20 LTS para Repocket
  if ! command -v node &>/dev/null || \
     [[ $(node -v 2>/dev/null | sed 's/v//;s/\..*//' || echo 0) -lt 18 ]]; then
    step "Instalando Node.js 20 LTS..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - 2>/dev/null
    apt-get install -y -qq nodejs
  fi
  log "Dependencias instaladas ✓ (Node $(node -v 2>/dev/null))"
}

# ── Docker mínimo (solo para PacketShare/ProxyRack sin binario ARM64) ─────────
install_docker_minimal() {
  command -v docker &>/dev/null && { log "Docker ya presente ✓"; return; }
  step "Instalando Docker (para PacketShare/ProxyRack)..."
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg 2>/dev/null
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" \
    | tee /etc/apt/sources.list.d/docker.list > /dev/null
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
  # daemon config optimizado
  cat > /etc/docker/daemon.json << 'DD'
{
  "log-driver": "json-file",
  "log-opts": {"max-size":"5m","max-file":"2"},
  "live-restore": true
}
DD
  systemctl enable --now docker
  log "Docker mínimo instalado ✓"
}

# ── FIX CRÍTICO: UFW + Oracle iptables ───────────────────────────────────────
fix_firewall() {
  hdr "FIREWALL (Oracle-safe)"
  # 1. Desactivar UFW — conflicto con Docker + reglas Oracle
  if systemctl is-active ufw &>/dev/null || systemctl is-enabled ufw &>/dev/null 2>/dev/null; then
    ufw --force disable 2>/dev/null || true
    systemctl disable ufw 2>/dev/null || true
    log "UFW desactivado (evita conflicto con Docker e iptables Oracle) ✓"
  fi

  # 2. Backup de reglas Oracle ANTES de modificar
  mkdir -p "${CFG}"
  iptables-save > "${CFG}/iptables-oracle-backup.rules" 2>/dev/null || true

  # 3. Añadir SIN vaciar (-C verifica antes de -A)
  _ar() { iptables -C "$@" 2>/dev/null || iptables -A "$@"; }
  _ar INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
  _ar INPUT -i lo -j ACCEPT
  _ar INPUT -p tcp --dport 22   -j ACCEPT
  _ar INPUT -p tcp --dport 4449 -j ACCEPT
  _ar INPUT -p tcp --dport 59850:60000 -j ACCEPT
  _ar INPUT -p udp --dport 59850:60000 -j ACCEPT
  _ar INPUT -p tcp --dport 8080 -j ACCEPT
  _ar INPUT -p tcp --dport 8443 -j ACCEPT
  _ar INPUT -p tcp --dport 9000 -j ACCEPT   # Portainer (opcional)
  _ar FORWARD -i docker0 -j ACCEPT
  _ar FORWARD -o docker0 -j ACCEPT
  _ar FORWARD -i br-+ -j ACCEPT
  _ar FORWARD -o br-+ -j ACCEPT

  netfilter-persistent save 2>/dev/null \
    || iptables-save > /etc/iptables/rules.v4 2>/dev/null || true

  log "Puertos abiertos (reglas Oracle preservadas) ✓"
  warn "TAMBIÉN en Oracle Console → VCN → Security Lists → Ingress:"
  echo "  TCP 4449 | TCP/UDP 59850-60000 | TCP 8080"
  echo "  O ejecuta: bash scripts/open_oracle_ports.sh"
}

# ── Optimizar kernel ARM64 ────────────────────────────────────────────────────
optimize_kernel() {
  hdr "OPTIMIZACIÓN DE RED ARM64"
  grep -q "bwstack" /etc/sysctl.conf 2>/dev/null && { log "Kernel ya optimizado ✓"; return; }

  # Detectar NIC física Oracle
  NIC=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5; exit}' || echo "eth0")
  echo "ORACLE_NIC=${NIC}" >> "${ENV_FILE}" 2>/dev/null || true

  cat >> /etc/sysctl.conf << SYSCTL

# ══ bwstack ARM64 v2.1 — ${BW_MBPS} Mbps egreso ══
# Buffers para ${CPUS} OCPUs
net.core.rmem_max                = 268435456
net.core.wmem_max                = 268435456
net.core.rmem_default            = 131072
net.core.wmem_default            = 131072
net.ipv4.tcp_rmem                = 4096 131072 268435456
net.ipv4.tcp_wmem                = 4096 131072 268435456
net.ipv4.udp_rmem_min            = 8192
net.ipv4.udp_wmem_min            = 8192
# TCP BBR (control de congestión Google)
net.core.default_qdisc           = fq
net.ipv4.tcp_congestion_control  = bbr
# Conexiones simultáneas (para proxy/VPN)
net.core.somaxconn               = 65535
net.ipv4.tcp_max_syn_backlog     = 65535
net.core.netdev_max_backlog      = 65535
net.ipv4.tcp_tw_reuse            = 1
net.ipv4.tcp_fin_timeout         = 15
net.ipv4.ip_local_port_range     = 1024 65535
# Forwarding
net.ipv4.ip_forward              = 1
net.ipv6.conf.all.forwarding     = 1
# Límite de archivos
fs.file-max                      = 2000000
# ══ end bwstack ══
SYSCTL

  modprobe tcp_bbr 2>/dev/null || true
  sysctl -p /etc/sysctl.conf 2>/dev/null || true

  cat >> /etc/security/limits.conf << 'LIM'
* soft nofile 1000000
* hard nofile 1000000
root soft nofile 1000000
root hard nofile 1000000
LIM

  # NIC offloads Oracle ARM64
  ethtool -G "$NIC" rx 4096 tx 4096 2>/dev/null || true
  ethtool -K "$NIC" rx-checksumming on tx-checksumming on \
    scatter-gather on tcp-segmentation-offload on \
    generic-segmentation-offload on generic-receive-offload on 2>/dev/null || true

  log "TCP BBR + buffers 256MB + NIC offloads ($NIC) ✓"
}

# ── Credenciales ──────────────────────────────────────────────────────────────
collect_creds() {
  hdr "CONFIGURACIÓN DE PROVEEDORES"

  if [[ -f "$ENV_FILE" ]] && grep -q "USE_MYSTERIUM" "$ENV_FILE" 2>/dev/null; then
    warn "Config existente detectada"
    read -rp "  ¿Reconfigurar credenciales? [s/N]: " RC
    [[ "${RC,,}" != "s" ]] && { source "$ENV_FILE"; return; }
  fi

  echo -e "${Y}Deja VACÍO los servicios que no quieras activar.${N}"
  echo -e "${D}Registra tu cuenta en cada web antes de instalar.${N}\n"

  # ── Mysterium ──
  printf "${C}┌─ 1/6 MYSTERIUM${N} (mystnodes.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | Pago: MYST crypto | Mejor rendimiento\n"
  printf "${C}│${N}  Se configura vía web en http://IP:4449 tras instalar\n"
  read -rp "└─ ¿Activar Mysterium? [S/n]: " _M
  USE_MYSTERIUM="${_M:-S}"

  # ── Traffmonetizer ──
  printf "\n${C}┌─ 2/6 TRAFFMONETIZER${N} (traffmonetizer.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | Pago: BTC | Token en tu dashboard\n"
  read -rp "└─ Token (vacío=omitir): " TM_TOKEN

  # ── Repocket ──
  printf "\n${C}┌─ 3/6 REPOCKET${N} (repocket.co)\n"
  printf "${C}│${N}  Acepta VPS ✓ | Pago: PayPal/Wise\n"
  read -rp "└─ Email (vacío=omitir): " RP_EMAIL
  RP_API_KEY=""
  [[ -n "${RP_EMAIL:-}" ]] && read -rp "  API Key: " RP_API_KEY

  # ── Bitping ──
  printf "\n${C}┌─ 4/6 BITPING${N} (bitping.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | Pago: SOL (Solana)\n"
  read -rp "└─ Email (vacío=omitir): " BP_EMAIL
  BP_PASSWORD=""
  [[ -n "${BP_EMAIL:-}" ]] && { read -rsp "  Password: " BP_PASSWORD; echo; }

  # ── PacketShare ──
  printf "\n${C}┌─ 5/6 PACKETSHARE${N} (packetshare.io)\n"
  printf "${C}│${N}  Acepta VPS ✓ | Pago: PayPal\n"
  read -rp "└─ Email (vacío=omitir): " PS_EMAIL
  PS_PASSWORD=""
  [[ -n "${PS_EMAIL:-}" ]] && { read -rsp "  Password: " PS_PASSWORD; echo; }

  # ── ProxyRack ──
  printf "\n${C}┌─ 6/6 PROXYRACK PEER${N} (peer.proxyrack.com)\n"
  printf "${C}│${N}  Acepta VPS ✓ | Pago: PayPal\n"
  read -rp "└─ API Key (vacío=omitir): " PR_API_KEY

  # Guardar .env
  cat > "$ENV_FILE" << EOF
# ══ Bandwidth Stack v2.1 — $(date) ══
PUBLIC_IP=${PUBLIC_IP}
ARCH=${ARCH}
CPUS=${CPUS}
BW_MBPS=${BW_MBPS}
HOSTNAME_ID=${HOSTNAME_ID}
INSTANCE_TYPE=ampere

# Proveedores
USE_MYSTERIUM=${USE_MYSTERIUM^^}
TM_TOKEN=${TM_TOKEN:-}
RP_EMAIL=${RP_EMAIL:-}
RP_API_KEY=${RP_API_KEY:-}
BP_EMAIL=${BP_EMAIL:-}
BP_PASSWORD=${BP_PASSWORD:-}
PS_EMAIL=${PS_EMAIL:-}
PS_PASSWORD=${PS_PASSWORD:-}
PR_API_KEY=${PR_API_KEY:-}
DEVICE_NAME=oracle-${HOSTNAME_ID}
EOF
  chmod 600 "$ENV_FILE"
  source "$ENV_FILE"
  log "Credenciales guardadas en $ENV_FILE ✓"
}

# ── 1. Mysterium — Binario nativo ARM64 ──────────────────────────────────────
install_mysterium() {
  [[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] || { step "Mysterium: omitido"; return; }
  hdr "1/6 MYSTERIUM (nativo ARM64)"

  if [[ ! -f "${BIN}/myst" ]]; then
    step "Descargando myst ARM64..."
    MYST_VER=$(curl -s https://api.github.com/repos/mysteriumnetwork/node/releases/latest \
      | jq -r '.tag_name' 2>/dev/null || echo "latest")
    curl -SL "https://github.com/mysteriumnetwork/node/releases/download/${MYST_VER}/myst_linux_arm64.tar.gz" \
      -o /tmp/myst.tar.gz 2>/dev/null || {
        warn "Descarga fallida → usando Docker fallback para Mysterium"
        docker run -d --name bws-mysterium --restart=unless-stopped \
          --cap-add NET_ADMIN --network=host \
          -v "${DATA}/mysterium:/var/lib/mysterium-node" \
          mysteriumnetwork/myst:latest \
          --udp.ports=59850:60000 service --agreed-terms-and-conditions 2>/dev/null || true
        return
      }
    tar -xzf /tmp/myst.tar.gz -C "$BIN" myst 2>/dev/null \
      || tar -xzf /tmp/myst.tar.gz -C "$BIN" 2>/dev/null || true
    chmod +x "${BIN}/myst"
    rm -f /tmp/myst.tar.gz
  fi

  useradd -r -s /bin/false myst 2>/dev/null || true
  chown -R myst:myst "${DATA}/mysterium" 2>/dev/null || true

  cat > "${SYSTEMD}/bwstack-mysterium.service" << MYST
[Unit]
Description=Mysterium Network Node (bwstack)
After=network-online.target
Wants=network-online.target

[Service]
User=myst
Group=myst
ExecStart=${BIN}/myst \\
  --data-dir=${DATA}/mysterium \\
  --ui.enable=true \\
  --ui.port=4449 \\
  --udp.ports=59850:60000 \\
  service \\
  --agreed-terms-and-conditions
Restart=always
RestartSec=10
LimitNOFILE=1000000
StandardOutput=append:${LOGS}/mysterium.log
StandardError=append:${LOGS}/mysterium.log

[Install]
WantedBy=multi-user.target
MYST

  systemctl daemon-reload
  systemctl enable --now bwstack-mysterium.service
  log "Mysterium nativo ARM64 → http://${PUBLIC_IP}:4449 ✓"
}

# ── 2. Traffmonetizer — Binario nativo ───────────────────────────────────────
install_traffmonetizer() {
  [[ -n "${TM_TOKEN:-}" ]] || { step "Traffmonetizer: omitido"; return; }
  hdr "2/6 TRAFFMONETIZER (nativo)"

  TM_BIN="${BIN}/traffmonetizer"
  if [[ ! -f "$TM_BIN" ]]; then
    step "Descargando traffmonetizer arm64..."
    curl -SL "https://traffmonetizer.com/files/cli_v2/linux/arm64/traffmonetizer" \
      -o "$TM_BIN" 2>/dev/null \
    || curl -SL "https://github.com/Traffmonetizer/cli_v2/releases/latest/download/traffmonetizer-linux-arm64" \
      -o "$TM_BIN" 2>/dev/null || {
        warn "Binario ARM64 no disponible → Docker mínimo"
        cat > "${BASE}/services/tm.yml" << TMDKR
version: "3.8"
services:
  traffmonetizer:
    image: traffmonetizer/cli_v2:latest
    restart: unless-stopped
    command: start accept --token ${TM_TOKEN}
    network_mode: host
    mem_limit: 80m
    logging:
      driver: json-file
      options: {max-size: "5m", max-file: "2"}
TMDKR
        docker compose -f "${BASE}/services/tm.yml" up -d 2>/dev/null || true
        log "Traffmonetizer via Docker mínimo ✓"
        return
      }
    chmod +x "$TM_BIN"
  fi

  cat > "${SYSTEMD}/bwstack-traffmonetizer.service" << TM
[Unit]
Description=Traffmonetizer (bwstack)
After=network-online.target

[Service]
ExecStart=${TM_BIN} start accept --token ${TM_TOKEN}
Restart=always
RestartSec=15
LimitNOFILE=100000
StandardOutput=append:${LOGS}/traffmonetizer.log
StandardError=append:${LOGS}/traffmonetizer.log

[Install]
WantedBy=multi-user.target
TM

  systemctl daemon-reload
  systemctl enable --now bwstack-traffmonetizer.service
  log "Traffmonetizer nativo ✓"
}

# ── 3. Repocket — npm nativo ──────────────────────────────────────────────────
install_repocket() {
  [[ -n "${RP_EMAIL:-}" ]] && [[ -n "${RP_API_KEY:-}" ]] || { step "Repocket: omitido"; return; }
  hdr "3/6 REPOCKET (npm nativo)"

  npm install -g @repocket/repocket 2>/dev/null \
    || { warn "npm install falló — verifica manualmente: npm i -g @repocket/repocket"; return; }

  RP_BIN=$(command -v repocket 2>/dev/null || echo "/usr/local/bin/repocket")

  cat > "${SYSTEMD}/bwstack-repocket.service" << RP
[Unit]
Description=Repocket (bwstack)
After=network-online.target

[Service]
Environment=RP_EMAIL=${RP_EMAIL}
Environment=RP_API_KEY=${RP_API_KEY}
ExecStart=${RP_BIN}
Restart=always
RestartSec=15
LimitNOFILE=100000
StandardOutput=append:${LOGS}/repocket.log
StandardError=append:${LOGS}/repocket.log

[Install]
WantedBy=multi-user.target
RP

  systemctl daemon-reload
  systemctl enable --now bwstack-repocket.service
  log "Repocket nativo (npm) ✓"
}

# ── 4. Bitping — Binario nativo ARM64 ────────────────────────────────────────
install_bitping() {
  [[ -n "${BP_EMAIL:-}" ]] && [[ -n "${BP_PASSWORD:-}" ]] || { step "Bitping: omitido"; return; }
  hdr "4/6 BITPING (nativo ARM64)"

  if [[ ! -f "${BIN}/bitpingd" ]]; then
    step "Descargando bitpingd arm64..."
    BP_URL=$(curl -s https://api.github.com/repos/bitping/bitpingd/releases/latest \
      | jq -r '.assets[]|select(.name|test("linux.*arm64"))|.browser_download_url' \
      2>/dev/null | head -1)
    [[ -n "${BP_URL:-}" ]] && curl -SL "$BP_URL" -o "${BIN}/bitpingd" 2>/dev/null \
      && chmod +x "${BIN}/bitpingd" \
      || { warn "Bitping: descarga fallida — omitiendo"; return; }
  fi

  cat > "${SYSTEMD}/bwstack-bitping.service" << BP
[Unit]
Description=Bitping (bwstack)
After=network-online.target

[Service]
Environment=BITPING_EMAIL=${BP_EMAIL}
Environment=BITPING_PASSWORD=${BP_PASSWORD}
ExecStart=${BIN}/bitpingd --data-directory=${DATA}/bitping
Restart=always
RestartSec=20
LimitNOFILE=100000
StandardOutput=append:${LOGS}/bitping.log
StandardError=append:${LOGS}/bitping.log

[Install]
WantedBy=multi-user.target
BP

  systemctl daemon-reload
  systemctl enable --now bwstack-bitping.service
  log "Bitping nativo ARM64 (env auth, no interactivo) ✓"
}

# ── 5+6. PacketShare + ProxyRack — Docker mínimo ─────────────────────────────
install_docker_services() {
  hdr "5+6: PACKETSHARE + PROXYRACK (Docker mínimo)"
  install_docker_minimal

  # PacketShare
  if [[ -n "${PS_EMAIL:-}" ]] && [[ -n "${PS_PASSWORD:-}" ]]; then
    docker rm -f bws-packetshare 2>/dev/null || true
    docker run -d --name bws-packetshare \
      --restart=unless-stopped \
      --network=host \
      --memory=80m \
      --log-opt max-size=5m --log-opt max-file=2 \
      packetshare/packetshare:latest \
      -accept-tos -email="${PS_EMAIL}" -password="${PS_PASSWORD}" 2>/dev/null \
      && log "PacketShare ✓" || warn "PacketShare: verificar manualmente"
  else
    step "PacketShare: omitido"
  fi

  # ProxyRack
  if [[ -n "${PR_API_KEY:-}" ]]; then
    docker rm -f bws-proxyrack 2>/dev/null || true
    docker run -d --name bws-proxyrack \
      --restart=unless-stopped \
      --network=host \
      --memory=80m \
      --log-opt max-size=5m --log-opt max-file=2 \
      -e API_KEY="${PR_API_KEY}" \
      -e DEVICE_NAME="${DEVICE_NAME:-oracle-$(hostname)}" \
      proxyrack/peer:latest 2>/dev/null \
      && log "ProxyRack ✓" || warn "ProxyRack: verificar manualmente"
  else
    step "ProxyRack: omitido"
  fi
}

# ── Web UI ────────────────────────────────────────────────────────────────────
install_webui() {
  hdr "WEB UI (puerto 8080)"
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  WEB_SRC="${SCRIPT_DIR}/../web/server.py"
  if [[ -f "$WEB_SRC" ]]; then
    cp "$WEB_SRC" "${WEB}/server.py"
  else
    warn "web/server.py no encontrado — Web UI desactivado"
    return
  fi

  cat > "${SYSTEMD}/bwstack-ui.service" << UI
[Unit]
Description=Bandwidth Stack Web UI
After=network-online.target

[Service]
ExecStart=/usr/bin/python3 ${WEB}/server.py
WorkingDirectory=${WEB}
Restart=always
RestartSec=5
Environment=BW_BASE=${BASE}
Environment=PORT=8080
StandardOutput=append:${LOGS}/webui.log
StandardError=append:${LOGS}/webui.log

[Install]
WantedBy=multi-user.target
UI

  systemctl daemon-reload
  systemctl enable --now bwstack-ui.service
  log "Web UI → http://${PUBLIC_IP}:8080 ✓"
}

# ── CLI bwctl ─────────────────────────────────────────────────────────────────
install_bwctl() {
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  cp "${SCRIPT_DIR}/bwctl.sh" /usr/local/bin/bwctl 2>/dev/null || true
  chmod +x /usr/local/bin/bwctl 2>/dev/null || true
  log "CLI 'bwctl' instalado (/usr/local/bin/bwctl) ✓"
}

# ── Systemd target para arranque automático ───────────────────────────────────
install_systemd_target() {
  cat > "${SYSTEMD}/bwstack.target" << 'TARGET'
[Unit]
Description=Bandwidth Stack v2.1
After=network-online.target docker.service
Wants=bwstack-mysterium.service bwstack-traffmonetizer.service
Wants=bwstack-repocket.service bwstack-bitping.service bwstack-ui.service

[Install]
WantedBy=multi-user.target
TARGET
  systemctl daemon-reload
  systemctl enable bwstack.target
  log "Systemd target bwstack.target ✓"
}

# ── Logrotate + cron ──────────────────────────────────────────────────────────
setup_maintenance() {
  # Logrotate
  cat > /etc/logrotate.d/bwstack << LR
${LOGS}/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0644 root root
}
LR

  # vnstat para monitorear consumo mensual de 10 TB
  systemctl enable --now vnstat 2>/dev/null || true
  NIC=${ORACLE_NIC:-$(ip route get 1.1.1.1 2>/dev/null | awk '{print $5;exit}' || echo eth0)}
  vnstat -i "$NIC" 2>/dev/null || true

  # Cron
  CTMP=$(mktemp)
  crontab -l 2>/dev/null | grep -v bwstack > "$CTMP" || true
  # healthcheck cada 5 min
  echo "*/5 * * * * /usr/local/bin/bwctl healthcheck >> ${LOGS}/cron.log 2>&1" >> "$CTMP"
  # update semanal domingo 4am
  echo "0 4 * * 0 /usr/local/bin/bwctl update >> ${LOGS}/update.log 2>&1" >> "$CTMP"
  # alerta si egreso > 8 TB en el mes (aviso antes del límite de 10 TB)
  echo "0 * * * * /usr/local/bin/bwctl check-tb >> ${LOGS}/tb.log 2>&1" >> "$CTMP"
  crontab "$CTMP"; rm "$CTMP"
  log "Logrotate + cron + vnstat configurados ✓"
}

# ── Test suite completo ───────────────────────────────────────────────────────
run_tests() {
  hdr "TEST SUITE — VERIFICACIÓN FINAL"
  source "$ENV_FILE" 2>/dev/null || true
  P=0; F=0; W=0
  _ok()   { echo -e "  ${G}[PASS]${N} $1"; ((P++)); }
  _fail() { echo -e "  ${R}[FAIL]${N} $1  ${R}← $2${N}"; ((F++)); }
  _warn() { echo -e "  ${Y}[WARN]${N} $1  ${Y}← $2${N}"; ((W++)); }
  _t()    { eval "$2" &>/dev/null && _ok "$1" || _fail "$1" "${3:-revisar}"; }

  echo "── Sistema ──"
  _t "IP forwarding"      "[[ \$(cat /proc/sys/net/ipv4/ip_forward) == 1 ]]" "sysctl -w net.ipv4.ip_forward=1"
  _t "TCP BBR activo"     "sysctl net.ipv4.tcp_congestion_control | grep -q bbr" "modprobe tcp_bbr && sysctl net.core.default_qdisc=fq"
  _t "UFW inactivo"       "! systemctl is-active ufw 2>/dev/null" "ufw disable"
  _t "ulimit nofile"      "[[ \$(ulimit -Hn 2>/dev/null || echo 0) -ge 100000 ]]" "edita /etc/security/limits.conf"
  _t "Node.js ≥18"        "node -v 2>/dev/null | grep -qE 'v(1[89]|[2-9][0-9])'" "apt install nodejs"

  echo ""
  echo "── Servicios ──"
  [[ "${USE_MYSTERIUM^^}" =~ ^(S|Y) ]] && \
    _t "Mysterium activo"       "systemctl is-active bwstack-mysterium" "bwctl restart mysterium"
  [[ -n "${TM_TOKEN:-}" ]] && \
    _t "Traffmonetizer activo"  "systemctl is-active bwstack-traffmonetizer || docker ps | grep -q traffmonetizer" "bwctl restart traffmonetizer"
  [[ -n "${RP_EMAIL:-}" ]] && \
    _t "Repocket activo"        "systemctl is-active bwstack-repocket" "bwctl restart repocket"
  [[ -n "${BP_EMAIL:-}" ]] && \
    _t "Bitping activo"         "systemctl is-active bwstack-bitping" "bwctl restart bitping"
  [[ -n "${PS_EMAIL:-}" ]] && \
    _t "PacketShare activo"     "docker ps | grep -q bws-packetshare" "docker start bws-packetshare"
  [[ -n "${PR_API_KEY:-}" ]] && \
    _t "ProxyRack activo"       "docker ps | grep -q bws-proxyrack" "docker start bws-proxyrack"
  _t "Web UI activo"            "systemctl is-active bwstack-ui" "bwctl restart ui"

  echo ""
  echo "── Red ──"
  _t "Puerto 4449 (Mysterium UI)"  "ss -tlnp | grep -q ':4449'" "revisar bwstack-mysterium"
  _t "Puerto 8080 (Dashboard)"     "ss -tlnp | grep -q ':8080'" "revisar bwstack-ui"
  _t "Conectividad internet"       "curl -s --max-time 5 https://1.1.1.1 -o /dev/null" "verificar red"
  _t "DNS funciona"                "curl -s --max-time 5 https://api.ipify.org -o /dev/null" "verificar DNS"

  echo ""
  echo "── Archivos ──"
  _t "config/.env existe"          "[[ -f ${ENV_FILE} ]]" "ejecutar install_arm64.sh"
  _t "bwctl instalado"             "command -v bwctl" "cp scripts/bwctl.sh /usr/local/bin/bwctl"
  _t "Cron healthcheck"            "crontab -l | grep -q bwstack" "ejecutar install_arm64.sh"
  _t "Systemd target habilitado"   "systemctl is-enabled bwstack.target" "systemctl enable bwstack.target"

  echo ""
  echo -e "  ────────────────────────────────────"
  echo -e "  ${G}${P} PASS${N}  ${Y}${W} WARN${N}  ${R}${F} FAIL${N}"
  [[ $F -eq 0 ]] \
    && echo -e "\n  ${G}${B}✅ STACK LISTO PARA PRODUCCIÓN${N}" \
    || echo -e "\n  ${Y}⚠ Corrige los FAIL antes de usar en producción${N}"
}

# ── Resumen ───────────────────────────────────────────────────────────────────
show_summary() {
  source "$ENV_FILE" 2>/dev/null || true
  hdr "✅ INSTALACIÓN ARM64 COMPLETADA"
  echo -e "  ${B}IP pública   :${N} $PUBLIC_IP"
  echo -e "  ${B}Egreso máx.  :${N} ${BW_MBPS} Mbps (${CPUS} OCPU × 1 Gbps)"
  echo -e "  ${B}Ingreso      :${N} Ilimitado"
  echo -e "  ${B}Arquitectura :${N} Nativo ARM64 (sin Docker overhead)"
  echo ""
  echo -e "  ${B}Paneles:${N}"
  echo -e "  • Mysterium UI : ${C}http://${PUBLIC_IP}:4449${N}  ← configura wallet aquí"
  echo -e "  • Dashboard    : ${C}http://${PUBLIC_IP}:8080${N}"
  echo ""
  echo -e "  ${B}CLI:${N}"
  echo -e "  ${Y}bwctl status${N}           # estado de todo"
  echo -e "  ${Y}bwctl logs mysterium${N}   # logs de un servicio"
  echo -e "  ${Y}bwctl bandwidth${N}        # monitor en vivo"
  echo -e "  ${Y}bwctl restart all${N}      # reiniciar todo"
  echo ""
  echo -e "  ${B}${R}⚠ Acción manual Oracle Console:${N}"
  echo -e "  VCN → Security Lists → Ingress Rules → añadir:"
  echo -e "  TCP 4449 | TCP/UDP 59850-60000 | TCP 8080"
  echo -e "  O ejecuta: ${Y}bash scripts/open_oracle_ports.sh${N}"
  echo ""
  echo -e "  ${B}Próximos pasos:${N}"
  echo -e "  1. Abre ${C}http://${PUBLIC_IP}:4449${N} → conecta tu wallet Mysterium"
  echo -e "  2. Ejecuta ${Y}bash scripts/setup_telegram.sh${N} para alertas"
  echo -e "  3. Espera 24-48h para que los nodos se verifiquen"
}

# ── MAIN ──────────────────────────────────────────────────────────────────────
main() {
  preflight
  make_dirs
  install_deps
  fix_firewall
  optimize_kernel
  collect_creds
  install_mysterium
  install_traffmonetizer
  install_repocket
  install_bitping
  install_docker_services
  install_webui
  install_bwctl
  install_systemd_target
  setup_maintenance
  sleep 5
  run_tests
  show_summary
}

main "$@"
